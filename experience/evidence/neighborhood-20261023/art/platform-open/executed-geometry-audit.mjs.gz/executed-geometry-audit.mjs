import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const root = '/workspace/TourGuideAI';
const beforeDir = path.join(root, 'experience/public/assets/neighborhoods/shijo-east');
const afterDir = path.join(root, 'artifacts/neighborhood-20261023/art/platform-open-optimized');
const tools = path.join(root, 'artifacts/neighborhood-20261021/art/tools/node_modules');
const { NodeIO } = await import(pathToFileURL(path.join(tools, '@gltf-transform/core/dist/index.js')));
const { ALL_EXTENSIONS } = await import(pathToFileURL(path.join(tools, '@gltf-transform/extensions/dist/index.js')));
const { MeshoptDecoder } = await import(pathToFileURL(path.join(tools, 'meshoptimizer/index.js')));
await MeshoptDecoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'meshopt.decoder': MeshoptDecoder });
const sha = data => createHash('sha256').update(data).digest('hex');
const json = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const beforeManifest = await json(path.join(beforeDir, 'manifest.json'));
const afterManifest = await json(path.join(afterDir, 'manifest.json'));
const targetIndex = 223;
const sourceId = 'kyoto-city:bldg_74454289-1d7a-4105-87ea-26e36c69bc44';
const sourceScene = await json(path.join(root, 'experience/src/neighborhoods/shijo-east/scene.json'));
const source = sourceScene.features.find(feature => feature.sourceId === sourceId);
const top = source.height.metres, bottom = source.baseHeightMetres ?? 0;
const sourcePoints = source.polygons.flatMap(polygon => [polygon.outer, ...(polygon.holes ?? [])])
  .flatMap(ring => ring.flatMap(([x, y]) => [bottom, top].map(z => [Math.fround(x), Math.fround(z), -Math.fround(y)])));
const compareKey = point => JSON.stringify(point.map(value => Object.is(value, -0) ? 0 : value));
const expectedPoints = new Set(sourcePoints.map(compareKey));
const transform = (point, matrix) => [0, 1, 2].map(axis => matrix[axis] * point[0] + matrix[axis + 4] * point[1] + matrix[axis + 8] * point[2] + matrix[axis + 12]);
const descriptors = manifest => [manifest.ground, manifest.context, ...manifest.cells.flatMap(cell => [cell.base, cell.near])];

async function proof(directory, file) {
  const document = await io.read(path.join(directory, file));
  const groups = new Map(), target = { triangles: 0, materials: {}, points: new Set(), roofs: [] };
  for (const node of document.getRoot().listNodes()) {
    const mesh = node.getMesh();
    if (!mesh) continue;
    const matrix = node.getWorldMatrix();
    for (const primitive of mesh.listPrimitives()) {
      const semantics = primitive.listSemantics().sort();
      const sourceSemantic = semantics.find(name => name.toUpperCase() === '_SOURCE_INDEX');
      if (!sourceSemantic) throw new Error('Missing source attribute: ' + mesh.getName());
      const sourceAccessor = primitive.getAttribute(sourceSemantic);
      const indices = primitive.getIndices().getArray();
      const material = primitive.getMaterial().getName();
      const vertices = Array.from({ length: primitive.getAttribute('POSITION').getCount() }, (_, index) =>
        JSON.stringify(semantics.map(semantic => [semantic, primitive.getAttribute(semantic).getElement(index, [])])));
      for (let offset = 0; offset < indices.length; offset += 3) {
        const corners = Array.from(indices.slice(offset, offset + 3));
        const index = Math.round(sourceAccessor.getScalar(corners[0]));
        // 保留的旧建筑简化结果含微小插值误差；分组用最近整数，完整原始属性仍参与逐字节签名。
        if (corners.some(corner => Math.abs(sourceAccessor.getScalar(corner) - index) > .001)) throw new Error('Mixed source triangle: ' + file);
        const points = corners.map(corner => vertices[corner]);
        const oriented = [0, 1, 2].map(start => [0, 1, 2].map(shift => points[(start + shift) % 3]).join('|')).sort()[0];
        const record = JSON.stringify({ material, matrix, oriented });
        if (index === targetIndex) {
          target.triangles++;
          target.materials[material] = (target.materials[material] ?? 0) + 1;
          const worldPoints = corners.map(corner => transform(primitive.getAttribute('POSITION').getElement(corner, []), matrix));
          for (const point of worldPoints) target.points.add(compareKey(point));
          if (material === 'roof' && worldPoints.every(point => point[1] === Math.fround(top))) target.roofs.push(record);
        } else {
          const records = groups.get(index) ?? [];
          records.push(record); groups.set(index, records);
        }
      }
    }
  }
  return { sources: Object.fromEntries([...groups].sort(([a], [b]) => a - b).map(([index, records]) =>
    [index, { triangles: records.length, sha256: sha(records.sort().join('\n')) }])),
    target: { ...target, points: [...target.points].sort(), roofs: { triangles: target.roofs.length, sha256: sha(target.roofs.sort().join('\n')) } } };
}

const beforeDescriptors = descriptors(beforeManifest), afterDescriptors = descriptors(afterManifest);
if (JSON.stringify(beforeDescriptors.map(item => item.file)) !== JSON.stringify(afterDescriptors.map(item => item.file))) throw new Error('Section identity changed');
const results = [];
for (let index = 0; index < beforeDescriptors.length; index++) {
  const before = beforeDescriptors[index], after = afterDescriptors[index];
  const beforeGeometry = [before, ...before.dependencies.filter(item => item.file.endsWith('.bin'))];
  const afterGeometry = [after, ...after.dependencies.filter(item => item.file.endsWith('.bin'))];
  const bytesExact = JSON.stringify(beforeGeometry.map(item => [item.file, item.bytes, item.sha256])) ===
    JSON.stringify(afterGeometry.map(item => [item.file, item.bytes, item.sha256]));
  if (bytesExact) { results.push({ file: before.file, containersByteExact: true }); continue; }
  const first = await proof(beforeDir, before.file), second = await proof(afterDir, after.file);
  if (JSON.stringify(first.sources) !== JSON.stringify(second.sources)) throw new Error('Unrelated source geometry changed: ' + before.file);
  if (first.target.triangles || second.target.triangles) {
    if (JSON.stringify(first.target.roofs) !== JSON.stringify(second.target.roofs)) throw new Error('Target source roof changed');
    const actualPoints = second.target.points.map(point => JSON.parse(point));
    const ring = source.polygons[0].outer;
    for (const point of actualPoints) {
      if (point[1] < Math.fround(bottom) || point[1] > Math.fround(top)) throw new Error('Target height changed');
      const crosses = ring.slice(0, -1).map((a, i) => {
        const b = ring[i + 1]; return (b[0] - a[0]) * (-point[2] - a[1]) - (b[1] - a[1]) * (point[0] - a[0]);
      });
      if (Math.min(...crosses) < -.0003 && Math.max(...crosses) > .0003) throw new Error('Target construction outside float32 footprint tolerance');
    }
    const topPoints = new Set(actualPoints.filter(point => point[1] === Math.fround(top)).map(compareKey));
    const expectedTop = new Set(sourcePoints.filter(point => point[1] === Math.fround(top)).map(compareKey));
    if (topPoints.size !== expectedTop.size || [...expectedTop].some(point => !topPoints.has(point))) throw new Error('Source roof ring changed');
    if (Math.min(...actualPoints.map(point => point[1])) !== bottom) throw new Error('Authored support base changed');
    if (second.target.triangles !== 108) throw new Error('Unexpected open assembly triangle count');
    if (Object.keys(second.target.materials).some(name => !['frame', 'roof'].includes(name))) throw new Error('Unexpected detailed material remains');
  }
  results.push({ file: before.file, containersByteExact: false, unrelatedSourcesExact: true,
    comparedSourceGroups: Object.keys(first.sources).length, beforeTarget: first.target, afterTarget: second.target });
}
const shared = [];
for (const item of beforeManifest.sharedResources) {
  const oldBytes = await fs.readFile(path.join(beforeDir, item.file));
  const newBytes = await fs.readFile(path.join(afterDir, item.file));
  if (!oldBytes.equals(newBytes)) throw new Error('Shared material resource changed: ' + item.file);
  shared.push({ file: item.file, bytes: oldBytes.length, sha256: sha(oldBytes) });
}
for (const file of ['lighting.json', 'source-ledger.json', 'source-review.json', 'references.json', 'river-context.json.gz']) {
  if (!(await fs.readFile(path.join(beforeDir, file))).equals(await fs.readFile(path.join(afterDir, file)))) throw new Error('Unrelated source or lighting changed: ' + file);
}
if (JSON.stringify(beforeManifest.featureTable) !== JSON.stringify(afterManifest.featureTable)) throw new Error('Runtime source identities changed');
const report = { status: 'pass', sourceId, sourceIndex: targetIndex,
  sourceSceneSha256: sha(await fs.readFile(path.join(root, 'experience/src/neighborhoods/shijo-east/scene.json'))),
  baselineManifestSha256: sha(await fs.readFile(path.join(beforeDir, 'manifest.json'))),
  candidateOptimizedManifestSha256: sha(await fs.readFile(path.join(afterDir, 'manifest.json'))),
  producerSha256: sha(await fs.readFile(new URL(import.meta.url))),
  height: { bottom, top, measuredHeightAttribute: source.height.measuredHeightAttribute },
  sections: results, sharedResources: shared,
  proof: 'Unchanged containers are byte-identical. Changed containers compare every unrelated source-indexed oriented triangle with complete decoded attributes, material name and world transform. Grouping rounds only inherited old-source-index interpolation below0.001; original attribute values remain in every signature. Target roof triangles/ring and base/top are exact; the108-triangle open assembly remains inside the source footprint within float32 tolerance and uses frame/roof materials only.' };
await fs.writeFile(path.join(root, 'artifacts/neighborhood-20261023/art/platform-open-preservation.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, sections: results.length, changedContainers: results.filter(item => !item.containersByteExact).map(item => item.file), target: results.filter(item => item.afterTarget?.triangles).map(item => ({ file: item.file, before: item.beforeTarget.triangles, after: item.afterTarget.triangles, materials: item.afterTarget.materials })) }));
