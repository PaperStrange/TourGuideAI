import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = '/workspace/TourGuideAI';
const directory = path.join(root, 'artifacts/neighborhood-20261023/art/platform-open-transport');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const manifestBytes = await fs.readFile(path.join(directory, 'manifest.json'));
const manifest = JSON.parse(manifestBytes);
const source = JSON.parse(await fs.readFile(path.join(root, 'experience/src/neighborhoods/shijo-east/geography.json')));
const spawnCells = manifest.cells.filter(cell => source.spawn.x >= cell.bounds.minX && source.spawn.x <= cell.bounds.maxX && source.spawn.y >= cell.bounds.minY && source.spawn.y <= cell.bounds.maxY);
if (spawnCells.length !== 1) throw new Error('Ambiguous spawn admission');
const unique = new Map();
for (const descriptor of [manifest.ground, manifest.context, manifest.lighting, spawnCells[0].base]) {
  for (const record of [descriptor, ...descriptor.dependencies]) unique.set(record.file, record);
}
let commonBytes = manifestBytes.length;
const resources = [];
for (const descriptor of unique.values()) {
  const transfer = descriptor.transport ?? descriptor;
  const bytes = await fs.readFile(path.join(directory, transfer.file));
  if (bytes.length !== transfer.bytes || hash(bytes) !== transfer.sha256) throw new Error('Resource identity mismatch');
  commonBytes += bytes.length;
  resources.push({ file: descriptor.file, decodedBytes: descriptor.bytes, transfer });
}
const rig = JSON.parse(await fs.readFile(path.join(directory, manifest.lighting.file)));
const travellerPath = 'experience/public/models/traveller.glb';
const traveller = await fs.readFile(path.join(root, travellerPath));
const critical = {};
for (const mode of ['day', 'night']) {
  const environment = rig.modes[mode].environment;
  const hdr = await fs.readFile(path.resolve(directory, path.dirname(manifest.lighting.file), environment.file));
  if (hash(hdr) !== environment.sha256) throw new Error('Environment identity mismatch');
  const totalBytes = commonBytes + traveller.length + hdr.length;
  if (totalBytes > 4 * 1024 * 1024) throw new Error('Required 3D startup budget exceeded');
  critical[mode] = { commonBytes, travellerBytes: traveller.length, hdrBytes: hdr.length, totalBytes,
    limitBytes: 4 * 1024 * 1024, headroomBytes: 4 * 1024 * 1024 - totalBytes,
    hdrSha256: hash(hdr), pass: true };
}
const compression = JSON.parse(await fs.readFile(path.join(directory, 'compression-report.json')));
if (compression.assets.length !== 74 || compression.assets.some(asset => asset.inputIssues.numErrors || asset.outputIssues.numErrors || asset.maximumPositionErrorMetres || asset.maximumUVError || !asset.sourceIndicesExact)) throw new Error('Asset validation or exact attribute proof failed');
const transport = JSON.parse(await fs.readFile(path.join(directory, 'transport-report.json')));
const report = { status: 'pass', producerSha256: hash(await fs.readFile(new URL(import.meta.url))),
  manifestSha256: hash(manifestBytes), spawn: source.spawn, startupCellId: spawnCells[0].id,
  meaning: 'Required 3D transfer includes manifest, resident ground/context, opening BASE, deduplicated shared dependencies, rig, selected HDR and traveller. Application HTML/JS/CSS/fonts, deferred sections and provenance reports are separate.',
  critical, traveller: { file: travellerPath, bytes: traveller.length, sha256: hash(traveller) },
  resources, validatedContainers: compression.assets.length,
  outputValidatorErrors: 0, maximumWorldPositionErrorMetres: 0, maximumUVError: 0, sourceIndicesExact: true,
  sectionBudgets: transport.sectionBudgets,
};
await fs.writeFile(path.join(root, 'artifacts/neighborhood-20261023/art/platform-open-startup-audit.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, manifest: report.manifestSha256, critical, validatedContainers: report.validatedContainers }));
