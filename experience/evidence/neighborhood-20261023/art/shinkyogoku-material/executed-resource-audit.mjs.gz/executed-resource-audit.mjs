import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';

const root = '/workspace/TourGuideAI';
const directory = path.join(root, 'artifacts/neighborhood-20261023/art/shinkyogoku-material-transport');
const baseline = path.join(root, 'artifacts/neighborhood-20261023/art/platform-open-transport');
const requireTool = createRequire(path.join(root, 'artifacts/neighborhood-20261021/art/tools/package.json'));
const sharp = requireTool('sharp');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async file => JSON.parse(await fs.readFile(file));
const manifestBytes = await fs.readFile(path.join(directory, 'manifest.json'));
const manifest = JSON.parse(manifestBytes);
const previous = await json(path.join(baseline, 'manifest.json'));
const geography = await json(path.join(root, 'experience/src/neighborhoods/shijo-east/geography.json'));
const source = await json(path.join(root, 'experience/src/neighborhoods/shijo-east/scene.json'));
const overrides = await json(path.join(directory, 'provenance.json'));
const sourceId = 'osm:way:551741577';
if (JSON.stringify(manifest.featureTable) !== JSON.stringify(previous.featureTable)) throw new Error('Runtime source identity changed');
if (manifest.featureTable['116'].sourceId !== sourceId) throw new Error('Material target index changed');
if (overrides.sourceMaterialOverrides.length !== 1 || overrides.sourceMaterialOverrides[0].sourceId !== sourceId) throw new Error('Unexpected material override');
const target = source.features.find(feature => feature.sourceId === sourceId);
if (target.topHeightMetres !== 5) throw new Error('Canonical canopy height changed');

const shared = [];
for (const record of previous.sharedResources) {
  const before = await fs.readFile(path.join(baseline, record.file));
  const after = await fs.readFile(path.join(directory, record.file));
  if (!before.equals(after)) throw new Error('Existing shared resource changed: ' + record.file);
  shared.push({ file: record.file, bytes: after.length, sha256: hash(after) });
}
for (const name of ['lighting.json', 'source-ledger.json', 'source-review.json', 'references.json', 'river-context.json.gz']) {
  if (!(await fs.readFile(path.join(baseline, name))).equals(await fs.readFile(path.join(directory, name)))) throw new Error('Existing source or light file changed: ' + name);
}
const added = manifest.sharedResources.filter(record => !previous.sharedResources.some(old => old.file === record.file));
const images = [];
for (const record of added) {
  if (!record.file.includes('shinkyogoku-panel')) throw new Error('Unexpected added resource: ' + record.file);
  const bytes = await fs.readFile(path.join(directory, record.file));
  if (hash(bytes) !== record.sha256 || bytes.length !== record.bytes) throw new Error('Added resource hash mismatch');
  const metadata = await sharp(bytes).metadata();
  if (metadata.width !== 128 || metadata.height !== 128) throw new Error('Unexpected panel image dimensions');
  const raw = await sharp(bytes).raw().toBuffer();
  const statistics = await sharp(bytes).stats();
  images.push({ ...record, width: metadata.width, height: metadata.height, channels: metadata.channels,
    decodedPixelSha256: hash(raw), decodedBytes: raw.length, rgba8EquivalentBytes: metadata.width * metadata.height * 4,
    channelsObserved: statistics.channels.map(channel => ({ min: channel.min, max: channel.max, mean: channel.mean })),
    rgba8WithMipEquivalentBytes: 87380 });
}
if (images.length !== 3) throw new Error('Expected three original panel resources');
const spawn = geography.spawn;
const cells = manifest.cells.filter(cell => spawn.x >= cell.bounds.minX && spawn.x <= cell.bounds.maxX && spawn.y >= cell.bounds.minY && spawn.y <= cell.bounds.maxY);
if (cells.length !== 1) throw new Error('Ambiguous spawn admission');
const resources = new Map();
for (const descriptor of [manifest.ground, manifest.context, manifest.lighting, cells[0].base]) {
  for (const record of [descriptor, ...descriptor.dependencies]) resources.set(record.file, record);
}
let commonBytes = manifestBytes.length;
for (const record of resources.values()) {
  const transfer = record.transport ?? record;
  const bytes = await fs.readFile(path.join(directory, transfer.file));
  if (hash(bytes) !== transfer.sha256 || bytes.length !== transfer.bytes) throw new Error('Startup resource identity mismatch');
  commonBytes += bytes.length;
}
const traveller = await fs.readFile(path.join(root, 'experience/public/models/traveller.glb'));
const rig = await json(path.join(directory, manifest.lighting.file));
const critical = {};
for (const mode of ['day', 'night']) {
  const environment = rig.modes[mode].environment;
  const hdr = await fs.readFile(path.resolve(directory, path.dirname(manifest.lighting.file), environment.file));
  if (hash(hdr) !== environment.sha256) throw new Error('HDR identity mismatch');
  const totalBytes = commonBytes + traveller.length + hdr.length;
  if (totalBytes > 4194304) throw new Error('Required 3D startup budget exceeded');
  critical[mode] = { commonBytes, travellerBytes: traveller.length, hdrBytes: hdr.length,
    totalBytes, headroomBytes: 4194304 - totalBytes, limitBytes: 4194304, hdrSha256: hash(hdr) };
}
const compression = await json(path.join(directory, 'compression-report.json'));
if (compression.assets.length !== 74 || compression.assets.some(asset => asset.inputIssues.numErrors || asset.outputIssues.numErrors || asset.maximumPositionErrorMetres || asset.maximumUVError || !asset.sourceIndicesExact)) throw new Error('Asset validation or exact attribute proof failed');
const transport = await json(path.join(directory, 'transport-report.json'));
const report = { status: 'pass', manifestSha256: hash(manifestBytes), baselineManifestSha256: hash(await fs.readFile(path.join(baseline, 'manifest.json'))),
  producerSha256: hash(await fs.readFile(new URL(import.meta.url))), sourceId, sourceIndex: 116,
  validatedContainers: 74, sourceTableExact: true, sharedResourcesExact: shared,
  addedOriginalImages: images, addedImageTransferBytes: images.reduce((sum, image) => sum + image.bytes, 0),
  rgba8EquivalentBytes: images.reduce((sum, image) => sum + image.rgba8EquivalentBytes, 0),
  rgba8WithMipEquivalentBytes: images.reduce((sum, image) => sum + image.rgba8WithMipEquivalentBytes, 0),
  allocationMeaning: 'Decoded image/storage equivalents; actual GPU allocation was not measured.',
  critical, startupCellId: cells[0].id,
  startupMeaning: 'Manifest, resident ground/context, opening BASE and deduplicated local resources plus traveller and selected HDR; application HTML/JS/CSS/fonts and deferred sections are separate.',
  startupIncludesNewPanelMaps: added.some(image => resources.has(image.file)), sectionBudgets: transport.sectionBudgets };
await fs.writeFile(path.join(root, 'artifacts/neighborhood-20261023/art/shinkyogoku-material-resource-audit.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, manifest: report.manifestSha256, images, critical, startupIncludesNewPanelMaps: report.startupIncludesNewPanelMaps }));
