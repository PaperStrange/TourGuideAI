import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = '/workspace/TourGuideAI';
const directory = path.join(root, 'artifacts/neighborhood-20261023/art/candidate-9-transport');
const baseline = path.join(root, 'artifacts/neighborhood-20261023/art/shinkyogoku-material-transport');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async file => JSON.parse(await fs.readFile(file));
const manifestBytes = await fs.readFile(path.join(directory, 'manifest.json'));
const manifest = JSON.parse(manifestBytes);
const previous = await json(path.join(baseline, 'manifest.json'));
const geography = await json(path.join(root, 'experience/src/neighborhoods/shijo-east/geography.json'));
if (JSON.stringify(manifest.featureTable) !== JSON.stringify(previous.featureTable)) throw new Error('Runtime source table changed');
const fileNames = records => records.map(record => record.file).sort();
if (JSON.stringify(fileNames(manifest.sharedResources)) !== JSON.stringify(fileNames(previous.sharedResources))) throw new Error('Shared resource inventory changed');
const shared = [];
for (const record of previous.sharedResources) {
  const before = await fs.readFile(path.join(baseline, record.file));
  const after = await fs.readFile(path.join(directory, record.file));
  if (!before.equals(after)) throw new Error('Shared material or environment changed: ' + record.file);
  shared.push({ file: record.file, bytes: after.length, sha256: hash(after) });
}
if (!(await fs.readFile(path.join(baseline, 'lighting.json'))).equals(await fs.readFile(path.join(directory, 'lighting.json')))) throw new Error('Lighting rig changed');
const spawn = geography.spawn;
const cells = manifest.cells.filter(cell => spawn.x >= cell.bounds.minX && spawn.x <= cell.bounds.maxX && spawn.y >= cell.bounds.minY && spawn.y <= cell.bounds.maxY);
if (cells.length !== 1) throw new Error('Ambiguous spawn admission');
const resources = new Map();
for (const descriptor of [manifest.ground, manifest.context, manifest.lighting, cells[0].base]) {
  for (const record of [descriptor, ...descriptor.dependencies]) resources.set(record.file, record);
}
let commonBytes = manifestBytes.length;
for (const record of resources.values()) {
  const transfer = record.transport ?? record;
  const bytes = await fs.readFile(path.join(directory, transfer.file));
  if (hash(bytes) !== transfer.sha256 || bytes.length !== transfer.bytes) throw new Error('Startup resource identity mismatch');
  commonBytes += bytes.length;
}
const traveller = await fs.readFile(path.join(root, 'experience/public/models/traveller.glb'));
const rig = await json(path.join(directory, manifest.lighting.file));
const critical = {};
for (const mode of ['day', 'night']) {
  const environment = rig.modes[mode].environment;
  const hdr = await fs.readFile(path.resolve(directory, path.dirname(manifest.lighting.file), environment.file));
  if (hash(hdr) !== environment.sha256) throw new Error('HDR identity mismatch');
  const totalBytes = commonBytes + traveller.length + hdr.length;
  if (totalBytes > 4194304) throw new Error('Required 3D startup budget exceeded');
  critical[mode] = { commonBytes, travellerBytes: traveller.length, hdrBytes: hdr.length,
    totalBytes, headroomBytes: 4194304 - totalBytes, limitBytes: 4194304, hdrSha256: hash(hdr) };
}
const compression = await json(path.join(directory, 'compression-report.json'));
if (compression.assets.length !== 74 || compression.assets.some(asset => asset.inputIssues.numErrors || asset.outputIssues.numErrors || asset.maximumPositionErrorMetres || asset.maximumUVError || !asset.sourceIndicesExact)) throw new Error('Asset validation or exact attribute proof failed');
const transport = await json(path.join(directory, 'transport-report.json'));
const report = { status: 'pass', manifestSha256: hash(manifestBytes),
  geographySha256: hash(await fs.readFile(path.join(root, 'experience/src/neighborhoods/shijo-east/geography.json'))),
  baselineManifestSha256: hash(await fs.readFile(path.join(baseline, 'manifest.json'))),
  producerSha256: hash(await fs.readFile(new URL(import.meta.url))),
  validatedContainers: 74, sourceTableExact: true, sharedResourcesExact: shared, addedImageBytes: 0,
  lightingRigExact: true, critical, startupCellId: cells[0].id,
  startupMeaning: 'Manifest, resident ground/context, opening BASE and deduplicated local resources plus traveller and selected HDR; application HTML/JS/CSS/fonts and deferred sections are separate.',
  sectionBudgets: transport.sectionBudgets };
await fs.writeFile(path.join(root, 'artifacts/neighborhood-20261023/art/candidate-9-resource-audit.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, manifest: report.manifestSha256, critical, validatedContainers: report.validatedContainers, addedImageBytes: 0 }));
