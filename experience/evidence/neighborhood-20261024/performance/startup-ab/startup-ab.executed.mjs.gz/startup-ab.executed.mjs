import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join, relative, extname } from 'node:path';
import { cpus, totalmem, platform, release } from 'node:os';

const repository = resolve(import.meta.dirname, '../../..');
const { chromium } = createRequire(join(repository, 'experience/package.json'))('playwright');
const sha = value => createHash('sha256').update(value).digest('hex');
const output = resolve(repository, process.env.STARTUP_AB_OUTPUT || 'artifacts/neighborhood-20261024/engineering/startup-ab');
if (!output.startsWith(join(repository, 'artifacts') + '/')) throw new Error('Output must stay inside repository artifacts.');
if (!process.env.CANDIDATE10_SHA256?.match(/^[a-f0-9]{64}$/)) throw new Error('CANDIDATE10_SHA256 must identify the frozen candidate10 package.');
const packages = [
  { id: 'candidate-9', directory: 'artifacts/neighborhood-20261023/candidate-9', expected: '1720fc5907c0c6f2b292aa0e728bcaad8ddbd6c776de7aec2b5a35a513609c9b' },
  { id: 'candidate-10', directory: 'artifacts/neighborhood-20261024/candidate-10', expected: process.env.CANDIDATE10_SHA256 },
];
const timeout = 120000, packId = 'shijo-east', prefix = '/assets/neighborhoods/shijo-east/';
const executablePath = '/usr/bin/chromium', browserArgs = ['--no-sandbox'];
const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
const proxyURL = proxy ? new URL(proxy) : null;
process.env.TMPDIR = join(repository, 'artifacts/tmp');
mkdirSync(process.env.TMPDIR, { recursive: true }); mkdirSync(output, { recursive: true });
const report = {
  startedAt: new Date().toISOString(), driverSha256: sha(readFileSync(new URL(import.meta.url))),
  conditions: { browserExpected: '151.0.7922.173', executablePath, browserArgs,
    viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1, reducedMotion: 'no-preference', lighting: 'day', locale: 'en',
    latencyMs: 80, downloadBytesPerSecond: 1250000, uploadBytesPerSecond: 1250000,
    proxyConfigured: Boolean(proxyURL), tlsVerification: true, temporaryDirectory: process.env.TMPDIR,
    ordering: 'Candidate9 cold/cache reload, then candidate10 cold/cache reload. Each package has its own fresh browser and context.',
    host: { platform: platform(), release: release(), logicalCPUs: cpus().length, memoryBytes: totalmem() },
    observer: 'Read-only requestAnimationFrame sampling until usable and full requested detail; records cost and counter gaps. Preview MutationObserver is passive.',
    renderTotals: 'The last renderer.info.render sample includes all submitted passes and may include shadow rendering.',
    mutationEquality: 'oldValueEqualsObservedFinal compares old and callback-time values for attributes/character data, or removed and added child text. A batched attribute A→B→A can satisfy this comparison; it does not establish a redundant assignment.',
    limitations: [
      'One observation per cache condition per package; no distribution or reliable speedup claim.',
      'This diagnostic does not replace the unchanged standard performance protocol, thresholds, input matrix or Q03.',
      'Candidate10 includes asset changes; package/file identities are retained to bound causal interpretation.',
      'Default software graphics cannot establish physical GPU fluency, display presentation or native hidden-tab behavior.',
      'Loopback CDP network throttling does not reproduce a real WAN/CDN.',
    ] },
  packages: [], fileDifferences: [], checks: [], errors: [],
};
const save = () => writeFileSync(join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n');
function check(id, pass, evidence) { report.checks.push({ id, pass: Boolean(pass), evidence }); save(); }

function snapshotPackage(specification) {
  const directory = resolve(repository, specification.directory), bytes = new Map();
  function collect(path) {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const file = join(path, entry.name);
      if (entry.isSymbolicLink()) throw new Error('Package contains a symbolic link.');
      if (entry.isDirectory()) collect(file);
      else if (entry.isFile()) bytes.set('/' + relative(directory, file), readFileSync(file));
    }
  }
  collect(directory);
  const files = [...bytes].sort(([a], [b]) => a.localeCompare(b)).map(([path, value]) => ({ path, bytes: value.length, sha256: sha(value) }));
  const manifestSha256 = sha(JSON.stringify(files));
  if (manifestSha256 !== specification.expected) throw new Error('Immutable package mismatch: ' + specification.id);
  const manifest = JSON.parse(bytes.get(prefix + 'manifest.json'));
  if (manifest.id !== packId) throw new Error('Missing neighborhood manifest.');
  return { bytes, metadata: { id: specification.id, directory, manifestSha256, files,
    neighborhood: { id: manifest.id, revision: manifest.revision, sha256: sha(bytes.get(prefix + 'manifest.json')) } } };
}

function installObserver(expectedPack) {
  const trace = { firstUsable: null, requestedDetail: null, fullDetail: null, failure: null, samples: [], workMs: [], gaps: [],
    mutations: { records: 0, oldValueEqualsObservedFinal: 0, workMs: [], fields: {} } };
  const ids = ['preview-kind', 'preview-title', 'preview-note', 'view-guidance', 'scene-status', 'scene-retry',
    'lighting-controls', 'lighting-day', 'lighting-night', 'solo-hint', 'solo-inspect', 'solo-keep'];
  const selector = ids.map(id => '#' + id).join(',');
  let frame, previousCounter = 0, previousSignature = '', stopped = false;
  const mutations = new MutationObserver(records => {
    const started = performance.now();
    for (const record of records) {
      const element = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement;
      const target = element?.closest(selector); if (!target) continue;
      const name = target.id + ':' + record.type + (record.attributeName ? ':' + record.attributeName : '');
      const item = trace.mutations.fields[name] ??= { records: 0, oldValueEqualsObservedFinal: 0 };
      const identical = record.type === 'attributes' ? record.oldValue === element.getAttribute(record.attributeName)
        : record.type === 'characterData' ? record.oldValue === record.target.data
          : [...record.removedNodes].map(node => node.textContent).join('') === [...record.addedNodes].map(node => node.textContent).join('');
      item.records++; trace.mutations.records++;
      if (identical) { item.oldValueEqualsObservedFinal++; trace.mutations.oldValueEqualsObservedFinal++; }
    }
    trace.mutations.workMs.push(performance.now() - started);
  });
  mutations.observe(document, { subtree: true, childList: true, characterData: true, characterDataOldValue: true,
    attributes: true, attributeOldValue: true });
  function sample() {
    const game = window.__TOUR_GAME__;
    if (!game || game.pack().packId !== expectedPack) return null;
    const render = game.renderer(), state = game.snapshot(), camera = game.camera(), route = game.route();
    const stream = game.streaming();
    return { observedMs: performance.now(), position: { x: state.x, y: state.y, height: state.height,
      edgeId: state.edgeId, edgeDistance: state.edgeDistance, heading: state.heading },
      destination: state.destination, paused: state.paused, tick: state.tick, camera,
      renderedFrames: render.renderedFrames, updateFrames: render.updateFrames,
      shadowUpdates: render.lighting.shadowUpdates, pendingShadow: render.lighting.lights.some(light => light.shadowNeedsUpdate),
      status: render.status, visible: render.visible, lighting: { mode: render.lighting.mode, phase: render.lighting.phase,
        pendingRequests: render.lighting.pendingRequests }, startup: render.startup,
      restoring: route?.restoring, blocked: route?.blocked, stream,
      ui: { status: document.querySelector('#scene-status')?.textContent,
        statusHidden: document.querySelector('#scene-status')?.hidden, retryHidden: document.querySelector('#scene-retry')?.hidden } };
  }
  function observe() {
    if (stopped) return;
    const start = performance.now(), value = sample();
    if (value) {
      const signature = JSON.stringify([value.renderedFrames, value.shadowUpdates, value.stream.revision]);
      if (signature !== previousSignature) {
        if (value.renderedFrames - previousCounter > 1) trace.gaps.push({ observedMs: value.observedMs,
          previous: previousCounter, current: value.renderedFrames });
        trace.samples.push(value); previousSignature = signature; previousCounter = value.renderedFrames;
      }
      if (!trace.firstUsable && value.status === 'ready' && value.renderedFrames > 0 && value.visible
        && value.lighting.phase === 'ready' && !value.paused && value.camera.enabled && !value.restoring && !value.blocked
        && !window.__HOME__?.snapshot().neighborhood?.busy) {
        const ground = window.__TOUR_GAME__.grounding();
        if (ground.inside && ground.hit) trace.firstUsable = { ...value, ground };
      }
      const desired = value.stream.cells.filter(cell => cell.desired);
      if (value.stream.cells.some(cell => cell.error)) trace.failure = value;
      if (trace.firstUsable && desired.length && desired.every(cell => cell.state === 'ready' && cell.level === cell.desired)
        && !value.stream.downloads.active && !value.stream.downloads.queued && !value.stream.attachments.active
        && !value.stream.attachments.queued) {
        trace.requestedDetail ??= value;
        // 另外保留最后一次真实阴影绘制完成后的状态，区分资源就绪与实际绘制。
        if (!value.pendingShadow) trace.fullDetail = value;
      }
    }
    const work = performance.now() - start; trace.workMs.push(work);
    if (!trace.fullDetail && !trace.failure) frame = requestAnimationFrame(observe);
  }
  window.__STARTUP_AB__ = { read: () => structuredClone(trace), sample,
    done: () => Boolean(trace.fullDetail || trace.failure),
    stop() { stopped = true; cancelAnimationFrame(frame); mutations.disconnect(); } };
  frame = requestAnimationFrame(observe);
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.gltf': 'model/gltf+json', '.glb': 'model/gltf-binary', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.webp': 'image/webp', '.woff2': 'font/woff2', '.svg': 'image/svg+xml' };
let browser, server;
try {
  // 在测量前读取不可变文件，测量期间所有响应直接使用这些字节。
  const snapshots = packages.map(snapshotPackage);
  const baseline = new Map(snapshots[0].metadata.files.map(file => [file.path, file]));
  const candidate = new Map(snapshots[1].metadata.files.map(file => [file.path, file]));
  for (const path of new Set([...baseline.keys(), ...candidate.keys()])) if (baseline.get(path)?.sha256 !== candidate.get(path)?.sha256) {
    report.fileDifferences.push({ path, baseline: baseline.get(path) ?? null, candidate: candidate.get(path) ?? null });
  }
  for (const snapshot of snapshots) {
    const value = { artifact: snapshot.metadata, entries: [], http: [], errors: [] };
    report.packages.push(value); save();
    const hashes = new Map(snapshot.metadata.files.map(file => [file.path, file.sha256]));
    server = createServer((request, response) => {
      const path = new URL(request.url, 'http://localhost').pathname === '/' ? '/index.html' : new URL(request.url, 'http://localhost').pathname;
      const bytes = snapshot.bytes.get(path), record = { at: new Date().toISOString(), path, method: request.method };
      value.http.push(record);
      if (!bytes) { record.status = 404; response.writeHead(404, { 'Cache-Control': 'no-store' }).end(); return; }
      const etag = '"' + hashes.get(path) + '"';
      response.setHeader('ETag', etag); response.setHeader('Content-Type', mime[extname(path)] || 'application/octet-stream');
      response.setHeader('Cache-Control', path.endsWith('.html') ? 'no-cache' : 'public, max-age=3600, immutable');
      if (request.headers['if-none-match'] === etag) { record.status = 304; response.writeHead(304).end(); return; }
      record.status = 200; record.bodyBytes = bytes.length; record.sha256 = hashes.get(path);
      response.setHeader('Content-Length', bytes.length); response.writeHead(200).end(bytes);
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    browser = await chromium.launch({ executablePath, headless: true, args: browserArgs,
      ...(proxyURL ? { proxy: { server: proxyURL.origin, bypass: 'localhost,127.0.0.1,[::1]',
        ...(proxyURL.username ? { username: decodeURIComponent(proxyURL.username), password: decodeURIComponent(proxyURL.password) } : {}) } } : {}) });
    value.browser = browser.version();
    if (value.browser !== report.conditions.browserExpected) throw new Error('System Chromium version changed.');
    const context = await browser.newContext({ viewport: report.conditions.viewport, deviceScaleFactor: 1, reducedMotion: 'no-preference' });
    await context.addInitScript(installObserver, packId);
    const page = await context.newPage(); page.setDefaultTimeout(timeout);
    page.on('pageerror', error => value.errors.push({ message: error.message, at: new Date().toISOString() }));
    const cdp = await context.newCDPSession(page);
    await cdp.send('Network.enable'); await cdp.send('Network.clearBrowserCache');
    await cdp.send('Network.setCacheDisabled', { cacheDisabled: false });
    await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 80,
      downloadThroughput: 1250000, uploadThroughput: 1250000 });
    let entry;
    const requests = new Map();
    cdp.on('Network.requestWillBeSent', event => {
      const item = { id: event.requestId, url: event.request.url, type: event.type, timestamp: event.timestamp };
      entry?.network.push(item); requests.set(event.requestId, item);
    });
    cdp.on('Network.responseReceived', event => {
      const item = requests.get(event.requestId); if (item) Object.assign(item, { status: event.response.status,
        diskCache: event.response.fromDiskCache, timing: event.response.timing });
    });
    cdp.on('Network.loadingFinished', event => { const item = requests.get(event.requestId); if (item) Object.assign(item,
      { finishedTimestamp: event.timestamp, encodedBytes: event.encodedDataLength }); });
    cdp.on('Network.loadingFailed', event => { const item = requests.get(event.requestId); if (item) item.failure = event.errorText; });
    const url = `http://127.0.0.1:${server.address().port}/?qa=1&lang=en&mode=explore&pack=${packId}`;
    for (const id of ['cold', 'warm']) {
      entry = { id, network: [] }; value.entries.push(entry); save();
      const response = id === 'cold' ? await page.goto(url, { waitUntil: 'domcontentloaded', timeout })
        : await page.reload({ waitUntil: 'domcontentloaded', timeout });
      entry.htmlSha256 = sha(await response.body());
      await page.waitForFunction(() => window.__STARTUP_AB__?.done(), null, { timeout });
      entry.observation = await page.evaluate(() => window.__STARTUP_AB__.read());
      const full = entry.observation.fullDetail;
      check(value.artifact.id + ':' + id + ':detail-ready', Boolean(full) && !entry.observation.failure, entry.observation.failure);
      if (!full) throw new Error('Actual requested sections failed to become ready.');
      await page.evaluate(() => window.__STARTUP_AB__.stop());
      entry.state = await page.evaluate(() => ({ home: window.__HOME__.snapshot(), player: window.__TOUR_GAME__.snapshot(),
        renderer: window.__TOUR_GAME__.renderer(), camera: window.__TOUR_GAME__.camera(), grounding: window.__TOUR_GAME__.grounding(),
        resources: performance.getEntriesByType('resource').map(resource => resource.toJSON()) }));
      check(value.artifact.id + ':' + id + ':index-identity', entry.htmlSha256 === hashes.get('/index.html'), entry.htmlSha256);
      check(value.artifact.id + ':' + id + ':real-ground', entry.state.grounding.inside && Boolean(entry.state.grounding.hit), entry.state.grounding);
      check(value.artifact.id + ':' + id + ':no-page-errors', value.errors.length === 0, value.errors);
      entry.opening = { view: entry.state.home.currentView, player: full.position,
        desiredSections: full.stream.cells.filter(cell => cell.desired).map(({ id, level, desired }) => ({ id, level, desired })),
        scene: entry.state.renderer.scene, renderTotals: entry.state.renderer.render };
      entry.metrics = { firstUsableMs: entry.observation.firstUsable.observedMs,
        requestedDetailMs: entry.observation.requestedDetail.observedMs, submittedDetailMs: full.observedMs,
        framesAtFirstUsable: entry.observation.firstUsable.renderedFrames, framesAtDetail: full.renderedFrames,
        shadowsAtDetail: full.shadowUpdates, previewMutations: entry.observation.mutations,
        observerWorkMaxMs: Math.max(...entry.observation.workMs), observerWorkTotalMs: entry.observation.workMs.reduce((sum, item) => sum + item, 0) };
      save(); console.log(value.artifact.id, id, JSON.stringify({ firstUsableMs: entry.metrics.firstUsableMs,
        requestedDetailMs: entry.metrics.requestedDetailMs, submittedDetailMs: entry.metrics.submittedDetailMs,
        framesAtDetail: full.renderedFrames, shadowsAtDetail: full.shadowUpdates,
        mutations: entry.metrics.previewMutations.records }));
    }
    value.graphics = await page.evaluate(() => {
      const gl = document.querySelector('#live-stage canvas').getContext('webgl2'), extension = gl.getExtension('WEBGL_debug_renderer_info');
      return { contextAttributes: gl.getContextAttributes(), renderer: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
        viewport: window.__TOUR_GAME__.viewport() };
    });
    await context.close(); await browser.close(); browser = null;
    await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); server = null;
  }
  function close(a, b) {
    if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) <= 1e-9;
    if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return a === b;
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every(key => close(a[key], b[key]));
  }
  const opening = report.packages[0].entries[0].opening;
  for (const result of report.packages) for (const entry of result.entries) {
    check(result.artifact.id + ':' + entry.id + ':opening-semantics', close(opening.view, entry.opening.view)
      && close(opening.player, entry.opening.player) && close(opening.desiredSections, entry.opening.desiredSections),
    { view: entry.opening.view, player: entry.opening.player, desiredSections: entry.opening.desiredSections });
  }
  check('same-graphics-quality', close(report.packages[0].graphics, report.packages[1].graphics), report.packages.map(value => value.graphics));
} catch (error) { report.errors.push({ message: error.message, stack: error.stack }); process.exitCode = 1; }
finally {
  if (browser) await browser.close();
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  report.finishedAt = new Date().toISOString(); save();
}
if (report.checks.some(check => !check.pass)) process.exitCode = 1;
