import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { readFileSync, readdirSync, mkdirSync, writeFileSync, openSync, closeSync } from 'node:fs';
import { resolve, join, relative, extname } from 'node:path';
import { createHash } from 'node:crypto';

const root = '/workspace/TourGuideAI';
if (!process.argv[2] || !process.argv[3]) throw new Error('Provide immutable build and output directories');
const dist = resolve(process.argv[2]), output = resolve(process.argv[3]);
if (!output.startsWith(join(root, 'artifacts') + '/')) throw new Error('Output must remain under ignored artifacts');
const sha = value => createHash('sha256').update(value).digest('hex');
const assets = new Map();
function collect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Unexpected package symlink');
    if (entry.isDirectory()) collect(path);
    else assets.set('/' + relative(dist, path), readFileSync(path));
  }
}
collect(dist);
if (!assets.has('/index.html')) throw new Error('Packaged index is missing');
const files = [...assets].sort(([a], [b]) => a.localeCompare(b)).map(([path, bytes]) => ({ path, bytes: bytes.length, sha256: sha(bytes) }));
const driverPath = join(root, 'experience/tools/homepage-performance.mjs');
const driver = readFileSync(driverPath);
mkdirSync(output, { recursive: true });
writeFileSync(join(output, 'homepage-performance.executed.mjs'), driver);
writeFileSync(join(output, 'server-wrapper.executed.mjs'), readFileSync(new URL(import.meta.url)));
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff': 'font/woff',
  '.woff2': 'font/woff2', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json', '.wasm': 'application/wasm', '.gz': 'application/gzip' };
const http = [];
const server = createServer((request, response) => {
  const url = new URL(request.url, 'http://localhost');
  const path = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname), bytes = assets.get(path);
  const identity = files.find(file => file.path === path);
  const item = { at: new Date().toISOString(), path, query: url.search, status: bytes ? 200 : 404,
    bytes: bytes?.length ?? 0, sha256: identity?.sha256 ?? null, finished: false };
  http.push(item); response.on('finish', () => { item.finished = true; });
  response.writeHead(item.status, { 'Content-Type': mime[extname(path)] || 'application/octet-stream',
    'Cache-Control': path.startsWith('/assets/') ? 'public, max-age=3600' : 'no-cache' });
  response.end(bytes || 'Resource unavailable');
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const url = 'http://127.0.0.1:' + server.address().port;
const binding = { startedAt: new Date().toISOString(), artifact: { directory: dist, files, manifestSha256: sha(JSON.stringify(files)) },
  driverSha256: sha(driver), wrapperSha256: sha(readFileSync(new URL(import.meta.url))), url,
  conditions: { originalDriverUnmodified: true, repetitions: 3, actualHTTP: true, interception: false,
    cache: '/assets/ public,max-age=3600; remaining files no-cache, matching the retained local Q03 diagnostic server policy',
    backend: 'Static packaged server; actual missing/API paths return404; real map/search providers use inherited proxy and TLS.' } };
writeFileSync(join(output, 'serving-binding.json'), JSON.stringify(binding, null, 2) + '\n');
const log = openSync(join(output, 'run.log'), 'w');
try {
  // 原始十二次观察驱动的开始、结束、操作和阈值保持不变。
  const child = spawn(process.execPath, [driverPath], { cwd: root, stdio: ['ignore', log, log], env: {
    ...process.env, TMPDIR: join(root, 'artifacts/tmp'), PERF_URL: url, PERF_OUTPUT: output, PERF_RUNS: '3',
    EXPERIENCE_QA_CHROMIUM: process.env.EXPERIENCE_QA_CHROMIUM || '/usr/bin/chromium' } });
  const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  binding.exitCode = code; process.exitCode = code ?? 1;
} finally {
  closeSync(log); await new Promise(resolve => server.close(resolve));
  binding.finishedAt = new Date().toISOString();
  writeFileSync(join(output, 'serving-binding.json'), JSON.stringify(binding, null, 2) + '\n');
  writeFileSync(join(output, 'http.json'), JSON.stringify(http, null, 2) + '\n');
}
