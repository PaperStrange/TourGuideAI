import { chromium } from '../../experience/node_modules/playwright/index.mjs';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { resolve, join, relative, extname, dirname } from 'node:path';
import { startNativeDisplay } from './native-display.mjs';

const repository = resolve(import.meta.dirname, '../..');
const name = process.env.NATIVE_VISIBILITY_NAME || 'candidate-12-native-context';
if (!/^[a-z0-9-]+$/.test(name)) throw new Error('Invalid evidence name');
const output = join(repository, 'artifacts/neighborhood-20261024/performance', name);
const dist = join(repository, 'artifacts/neighborhood-20261024/candidate-12');
const expectedPackage = 'e86aa1c715fb76cd111feae41a0383ee34005aefd64fe5c48eba7615676e5733';
const prefix = '/assets/neighborhoods/shijo-east/';
const sha = value => createHash('sha256').update(value).digest('hex');
const files = new Map();
function collect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const file = join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Captured package includes a symbolic link');
    if (entry.isDirectory()) collect(file);
    else if (entry.isFile()) files.set('/' + relative(dist, file), readFileSync(file));
  }
}
collect(dist);
const identities = [...files].sort(([a], [b]) => a.localeCompare(b)).map(([path, bytes]) => ({ path, bytes: bytes.length, sha256: sha(bytes) }));
if (sha(JSON.stringify(identities)) !== expectedPackage) throw new Error('Candidate 12 identity mismatch');
mkdirSync(dirname(output), { recursive: true }); mkdirSync(output, { recursive: false });
const report = { startedAt: new Date().toISOString(), driverSha256: sha(readFileSync(new URL(import.meta.url))),
  helperSha256: sha(readFileSync(new URL('./native-display.mjs', import.meta.url))),
  artifact: { directory: dist, manifestSha256: expectedPackage, files: identities },
  conditions: { scope: 'Genuine native-tab visibility and actual application work while hidden; physical GPU and ordinary-config performance remain unverified.',
    viewport: [1440, 1000], deviceScaleFactor: 1, reducedMotion: 'no-preference', locale: 'en', lighting: 'day',
    headless: false, executable: '/usr/bin/chromium', args: null,
    network: { latencyMs: 80, downloadBytesPerSecond: 1250000, uploadBytesPerSecond: 1250000,
      delivery: 'Actual loopback HTTP, immutable package bytes, no request interception, no backend, TLS checks unchanged.' },
    hiddenObservation: 'A real second tab is brought forward. After a native hidden transition and 1500ms settling, actual counters and requests are sampled over 2000ms.',
    automation: 'Direct native Chromium launch; public connectOverCDP({noDefaults:true}) attaches only to the existing default context. Playwright focus/media/default download emulation is not enabled.',
    overrides: 'Only the public viewport size is set to1440x1000; no document visibility, lifecycle or focus override commands.' },
  checks: [], errors: [], http: [], requests: [], identities: {}, snapshots: {} };
const save = () => writeFileSync(join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n');
const check = (id, pass, evidence) => { report.checks.push({ id, pass: Boolean(pass), evidence }); save(); };
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json',
  '.gltf': 'model/gltf+json', '.glb': 'model/gltf-binary', '.wasm': 'application/wasm', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff': 'font/woff', '.woff2': 'font/woff2' };
const server = createServer((request, response) => {
  const pathname = new URL(request.url, 'http://localhost').pathname;
  const path = pathname === '/' ? '/index.html' : decodeURIComponent(pathname);
  const bytes = files.get(path), status = bytes ? 200 : 404;
  report.http.push({ path, status, at: new Date().toISOString(), bytes: bytes?.length ?? 0 });
  response.writeHead(status, { 'Content-Type': mime[extname(path)] || 'application/octet-stream',
    'Cache-Control': path.endsWith('.html') ? 'no-cache' : 'public, max-age=3600, immutable' });
  response.end(bytes || 'Not found');
});
function observeVisibility() {
  window.__NATIVE_VISIBILITY__ = { initial: { at: performance.now(), hidden: document.hidden, state: document.visibilityState }, events: [] };
  document.addEventListener('visibilitychange', event => window.__NATIVE_VISIBILITY__.events.push({
    at: performance.now(), hidden: document.hidden, state: document.visibilityState, trusted: event.isTrusted }));
}
function snapshot() {
  const game = window.__TOUR_GAME__;
  return { at: performance.now(), hidden: document.hidden, visibility: document.visibilityState,
    events: window.__NATIVE_VISIBILITY__, renderer: game?.renderer(), state: game?.snapshot(),
    camera: game?.camera(), stream: game?.streaming(), route: game?.route(), ground: game?.grounding(),
    savedView: window.__HOME__?.snapshot().currentView };
}
let display, browser, context, page, chromeProcess, chromeExited, chromeLog;
try {
  display = await startNativeDisplay({ name, display: 92, screen: '1440x1000x24' });
  report.display = display.manifest;
  process.env.TMPDIR = display.env.TMPDIR;
  const allowed = spawnSync('/usr/bin/xdpyinfo', ['-display', display.env.DISPLAY], { env: display.env, encoding: 'utf8' });
  report.x11 = { status: allowed.status, stdout: allowed.stdout, stderr: allowed.stderr };
  check('authenticated-x11-client-connects', allowed.status === 0, { status: allowed.status });
  if (allowed.status !== 0) throw new Error('Authenticated native X11 connection failed');
  const emptyAuthority = join(display.manifest.directory, 'empty-authority');
  writeFileSync(emptyAuthority, '', { mode: 0o600 });
  const denied = spawnSync('/usr/bin/xdpyinfo', ['-display', display.env.DISPLAY], {
    env: { ...display.env, XAUTHORITY: emptyAuthority }, encoding: 'utf8' });
  check('x11-rejects-missing-cookie', denied.status !== 0, { status: denied.status, stderr: denied.stderr });
  if (denied.status === 0) throw new Error('Unauthenticated native X11 connection accepted');
  check('native-server-retains-glx-and-disables-mitshm', /\bGLX\b/.test(allowed.stdout) && !/MIT-SHM/.test(allowed.stdout), {});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const inheritedProxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
  const proxy = inheritedProxy ? new URL(inheritedProxy) : null;
  if (proxy?.username || proxy?.password) throw new Error('The direct browser requires separately configured authenticated proxy support');
  const profile = join(display.manifest.directory, 'chrome-profile'); mkdirSync(profile, { mode: 0o700 });
  const args = ['--no-sandbox', '--no-first-run', '--no-default-browser-check', '--enable-automation',
    '--disable-dev-shm-usage', '--disable-breakpad', '--disable-component-update', '--lang=en-US',
    '--enable-unsafe-swiftshader', '--force-color-profile=srgb',
    '--window-size=1448,1085', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    `--user-data-dir=${profile}`, ...(proxy ? [`--proxy-server=${proxy.origin}`, '--proxy-bypass-list=localhost;127.0.0.1;[::1]'] : []), 'about:blank'];
  report.conditions.args = args;
  chromeLog = openSync(join(output, 'chromium.log'), 'wx', 0o600);
  chromeProcess = spawn(report.conditions.executable, args, { env: display.env,
    cwd: display.manifest.directory, stdio: ['ignore', chromeLog, chromeLog] });
  chromeExited = new Promise(resolve => { chromeProcess.once('exit', (code, signal) => resolve({ code, signal }));
    chromeProcess.once('error', error => resolve({ error: error.message })); });
  report.conditions.pid = chromeProcess.pid;
  const activePort = join(profile, 'DevToolsActivePort'), deadline = Date.now() + 15000;
  while (!existsSync(activePort)) {
    if (chromeProcess.exitCode !== null || chromeProcess.signalCode !== null || Date.now() > deadline)
      throw new Error('Native Chromium did not expose its DevTools endpoint');
    await delay(100);
  }
  const port = readFileSync(activePort, 'utf8').split('\n')[0];
  if (!/^\d+$/.test(port)) throw new Error('Unexpected DevTools endpoint');
  const automationArtifacts = join(output, 'playwright'); mkdirSync(automationArtifacts);
  browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`, { noDefaults: true,
    artifactsDir: automationArtifacts, isLocal: true });
  report.browser = browser.version();
  const browserCDP = await browser.newBrowserCDPSession();
  report.conditions.actualCommandLine = await browserCDP.send('Browser.getBrowserCommandLine');
  report.systemInfo = await browserCDP.send('SystemInfo.getInfo');
  context = browser.contexts()[0];
  if (!context) throw new Error('Native default browser context is missing');
  await context.addInitScript(observeVisibility);
  page = context.pages()[0];
  if (!page) throw new Error('Native starting tab is missing');
  await page.setViewportSize({ width: 1440, height: 1000 }); page.setDefaultTimeout(120000);
  page.on('pageerror', error => { report.errors.push({ message: error.message }); save(); });
  const pageCDP = await context.newCDPSession(page);
  await pageCDP.send('Performance.enable'); await pageCDP.send('Network.enable');
  await pageCDP.send('Network.emulateNetworkConditions', { offline: false, latency: 80,
    downloadThroughput: 1250000, uploadThroughput: 1250000 });
  pageCDP.on('Network.requestWillBeSent', event => report.requests.push({ url: event.request.url, type: event.type, timestamp: event.timestamp }));
  async function identify(targetPage) {
    const session = await context.newCDPSession(targetPage);
    const { targetInfo } = await session.send('Target.getTargetInfo');
    const window = await browserCDP.send('Browser.getWindowForTarget', { targetId: targetInfo.targetId });
    await session.detach(); return { target: targetInfo, window };
  }
  report.pageURL = `${origin}/?qa=1&lang=en&mode=explore&pack=shijo-east`;
  await page.goto(report.pageURL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => {
    const game = window.__TOUR_GAME__;
    if (!game || game.pack().packId !== 'shijo-east') return false;
    const r = game.renderer(), state = game.snapshot(), route = game.route(), stream = game.streaming(), ground = game.grounding();
    if (stream.cells.some(cell => cell.error)) throw new Error('Actual neighborhood has a section error');
    const desired = stream.cells.filter(cell => cell.desired);
    return r.status === 'ready' && r.renderedFrames > 0 && r.visible && r.lighting.phase === 'ready'
      && !state.paused && game.camera().enabled && !route?.blocked && !route?.restoring
      && !window.__HOME__?.snapshot().neighborhood?.busy && ground.inside && ground.hit
      && desired.length > 0 && desired.every(cell => cell.state === 'ready' && cell.level === cell.desired)
      && !stream.downloads.active && !stream.downloads.queued && !stream.attachments.active && !stream.attachments.queued;
  }, null, { polling: 100, timeout: 180000 });
  report.identities.application = await identify(page);
  report.conditions.actualPage = await page.evaluate(() => ({ width: innerWidth, height: innerHeight, dpr: devicePixelRatio,
    language: navigator.language, reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches }));
  check('native-context-matches-viewport-and-motion', report.conditions.actualPage.width === 1440
    && report.conditions.actualPage.height === 1000 && report.conditions.actualPage.dpr === 1
    && !report.conditions.actualPage.reducedMotion, report.conditions.actualPage);
  report.snapshots.visible = await page.evaluate(snapshot);
  report.graphics = await page.evaluate(() => {
    const gl = document.querySelector('#live-stage canvas').getContext('webgl2');
    const extension = gl.getExtension('WEBGL_debug_renderer_info');
    return { renderer: gl.getParameter(gl.RENDERER), unmaskedRenderer: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : null,
      attributes: gl.getContextAttributes(), viewport: window.__TOUR_GAME__.viewport() };
  });
  check('actual-neighborhood-ready-and-visible', !report.snapshots.visible.hidden, report.snapshots.visible);
  check('application-antialiasing-retained', report.graphics.attributes.antialias === true, report.graphics);
  const blank = await context.newPage(); await blank.goto('about:blank'); await blank.bringToFront();
  report.identities.blank = await identify(blank);
  check('actual-pages-share-native-window', report.identities.application.window.windowId === report.identities.blank.window.windowId, report.identities);
  if (report.identities.application.window.windowId !== report.identities.blank.window.windowId) throw new Error('Native pages do not share one browser window');
  save();
  await page.waitForFunction(() => document.hidden, null, { polling: 100, timeout: 10000 });
  await page.waitForTimeout(1500);
  const before = await page.evaluate(snapshot), httpIndex = report.http.length, requestIndex = report.requests.length;
  const cpuBefore = Object.fromEntries((await pageCDP.send('Performance.getMetrics')).metrics.map(value => [value.name, value.value]));
  await page.waitForTimeout(2000);
  const cpuAfter = Object.fromEntries((await pageCDP.send('Performance.getMetrics')).metrics.map(value => [value.name, value.value]));
  const after = await page.evaluate(snapshot);
  report.snapshots.hidden = { before, after, elapsedMs: after.at - before.at,
    renderDelta: after.renderer.renderedFrames - before.renderer.renderedFrames,
    updateDelta: after.renderer.updateFrames - before.renderer.updateFrames,
    neighborhoodRequests: report.requests.slice(requestIndex).filter(item => new URL(item.url).pathname.startsWith(prefix)),
    servedNeighborhoodRequests: report.http.slice(httpIndex).filter(item => item.path.startsWith(prefix)),
    taskDurationMs: (cpuAfter.TaskDuration - cpuBefore.TaskDuration) * 1000,
    scriptDurationMs: (cpuAfter.ScriptDuration - cpuBefore.ScriptDuration) * 1000 };
  const hidden = report.snapshots.hidden;
  check('native-hidden-event-observed', after.events.events.some(event => event.hidden && event.trusted), after.events);
  check('hidden-neighborhood-zero-work', before.hidden && after.hidden && hidden.renderDelta === 0 && hidden.updateDelta === 0
    && hidden.neighborhoodRequests.length === 0 && hidden.servedNeighborhoodRequests.length === 0, hidden);
  report.snapshots.blank = await blank.evaluate(() => ({ hidden: document.hidden, visibility: document.visibilityState }));
  await blank.close(); await page.bringToFront();
  await page.waitForFunction(() => !document.hidden && window.__TOUR_GAME__.renderer().visible
    && !window.__TOUR_GAME__.snapshot().paused, null, { polling: 100, timeout: 10000 });
  report.snapshots.returned = await page.evaluate(snapshot);
  const returned = report.snapshots.returned;
  check('native-visible-return-observed', returned.events.events.some(event => !event.hidden && event.trusted), returned.events);
  check('private-pose-retained-across-native-hide', returned.state.x === before.state.x && returned.state.y === before.state.y
    && returned.state.edgeId === before.state.edgeId && before.savedView !== undefined
    && JSON.stringify(returned.savedView) === JSON.stringify(before.savedView), { before: before.savedView, after: returned.savedView });
  check('no-page-exceptions', report.errors.length === 0, report.errors);
  check('no-missing-package-resources', report.http.every(item => item.status !== 404 || item.path.startsWith('/api/') || item.path === '/favicon.ico'),
    report.http.filter(item => item.status === 404));
} catch (error) {
  report.failure = { name: error.name, message: error.message, stack: error.stack };
  if (page && !page.isClosed()) report.snapshots.failed = await page.evaluate(snapshot).catch(readError => ({ error: readError.message }));
  check('native-visibility-run-completed', false, report.failure);
  process.exitCode = 1;
} finally {
  await context?.close(); await browser?.close();
  if (chromeProcess) {
    chromeProcess.kill('SIGTERM');
    const force = setTimeout(() => chromeProcess.kill('SIGKILL'), 5000);
    try { report.chromeExit = await chromeExited; } finally { clearTimeout(force); }
  }
  if (chromeLog !== undefined) closeSync(chromeLog);
  if (server.listening) await new Promise(resolve => server.close(resolve));
  await display?.close();
  report.finishedAt = new Date().toISOString(); save();
  if (report.checks.some(check => !check.pass)) process.exitCode = 1;
}
console.log(JSON.stringify({ output, checks: report.checks.map(({ id, pass }) => ({ id, pass })), failure: report.failure }));
