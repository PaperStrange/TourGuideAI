import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import sys


ROOT = Path('/workspace/TourGuideAI')
sys.path.insert(0, str(ROOT / 'experience/art'))
from neighborhood_mesh import MeshBatch, building_geometry, vertical_boundary_geometry


producer = ROOT / 'experience/art/build_neighborhood.py'
selected = {'sha256', 'bounds_of', 'load_boundary_closures', 'append_ground_boundary_closures', 'prepare_features'}
tree = ast.parse(producer.read_text())
namespace = {'ROOT': ROOT, 'Path': Path, 'json': json, 'math': math, 'hashlib': hashlib,
             'MeshBatch': MeshBatch, 'vertical_boundary_geometry': vertical_boundary_geometry}
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected],
                        type_ignores=[]), str(producer), 'exec'), namespace)
scene = json.loads((ROOT / 'experience/src/neighborhoods/shijo-east/scene.json').read_text())
navigation = json.loads((ROOT / 'experience/src/neighborhoods/shijo-east/geography.json').read_text())
prepared = json.loads((ROOT / 'artifacts/neighborhood-20261023/world/art-selection.json').read_text())
style = json.loads((ROOT / 'experience/art/neighborhood-style.json').read_text())
closures = namespace['load_boundary_closures'](scene, prepared, style)
features = namespace['prepare_features'](scene, navigation, style, prepared, closures)
source_indices = {feature['sourceId']: index for index, feature in enumerate(features)}
for surface in [dict(item, sourceId=item['id']) for item in scene['surfaces']] + prepared['displayMaterialSurfaces']:
    if surface['sourceId'] not in source_indices:
        source_indices[surface['sourceId']] = len(source_indices)
for source_id, override in style['sourceBoundaryClosures'].items():
    assert source_indices[source_id] == override['expectedSourceIndex']
target = features[731]
old_target = dict(target)
del old_target['boundaryClosures']
recipe = dict(style['recipes'][target['recipeId']], facadeEdges=target['facadeEdges'],
              arcadeFacadeEdges=target['arcadeFacadeEdges'], arcadeRecipe=style['recipes']['market-front'])
counts = {}
for lod in ('base', 'near'):
    before = {name: MeshBatch() for name in style['materials']}
    after = {name: MeshBatch() for name in style['materials']}
    assert building_geometry(old_target, recipe, lod, 731, before) == building_geometry(target, recipe, lod, 731, after)
    for name, batch in before.items():
        current = after[name]
        assert current.vertices[:len(batch.vertices)] == batch.vertices
        assert current.faces[:len(batch.faces)] == batch.faces
        assert current.source_indices[:len(batch.source_indices)] == batch.source_indices
        if name != recipe['wallMaterial']:
            assert current.vertices == batch.vertices and current.faces == batch.faces
    current, previous = after[recipe['wallMaterial']], before[recipe['wallMaterial']]
    assert current.triangles - previous.triangles == 8
    counts[lod] = {'priorTriangles': sum(batch.triangles for batch in before.values()), 'addedTriangles': 8}

# 使用实际常驻表面构造，随后执行生产入口以确认所有导航批次保持原样。
surfaces = prepared['displayMaterialSurfaces'] + prepared['walkableMaterialSurfaces']
surfaces += [dict(feature, material={'water': 'water', 'green': 'green', 'bridge': 'paving'}[feature['kind']], walkable=False)
             for feature in features if feature['kind'] in ('water', 'green', 'bridge')]
ground = {}
for surface in surfaces:
    key = (surface['material'], bool(surface.get('walkable')))
    data = ground.setdefault(key, MeshBatch())
    for polygon in surface['polygons']:
        data.top(polygon['triangles'], surface['topHeightMetres'], source_indices[surface['sourceId']])
before_ground = copy.deepcopy(ground)
namespace['append_ground_boundary_closures'](ground, closures, source_indices)
for key, batch in before_ground.items():
    current = ground[key]
    assert current.vertices[:len(batch.vertices)] == batch.vertices
    assert current.faces[:len(batch.faces)] == batch.faces
    assert current.source_indices[:len(batch.source_indices)] == batch.source_indices
    if key != ('paving', False):
        assert current.vertices == batch.vertices and current.faces == batch.faces
        assert current.source_indices == batch.source_indices
assert ground[('paving', False)].triangles - before_ground[('paving', False)].triangles == 4
for source_id, closure in closures.items():
    batch = MeshBatch()
    vertical_boundary_geometry(closure['segments'], batch, source_indices[source_id])
    for segment, face in zip(closure['segments'], batch.faces):
        vertices = [batch.vertices[index] for index in face]
        assert {point[2] for point in vertices} == {segment['bottomHeightMetres'], segment['topHeightMetres']}
        assert {point[:2] for point in vertices} == {tuple(segment['from']), tuple(segment['to'])}
        start, end = segment['from'], segment['to']
        normal = ((end[1] - start[1]) * (vertices[2][2] - vertices[1][2]),
                  -(end[0] - start[0]) * (vertices[2][2] - vertices[1][2]))
        assert normal[0] * (end[1] - start[1]) - normal[1] * (end[0] - start[0]) > 0
report = {'status': 'pass', 'sourceIds': list(closures), 'building': counts,
          'residentAddedTriangles': 4, 'addedRoadSourceIndices': [20, 151],
          'existingBuildingFacesAttributesExact': True, 'existingGroundFacesAttributesExact': True,
          'allWalkableBatchesExact': True, 'roadClosureBatchWalkable': False,
          'exactAuditedEndpointsHeightsAndOutwardNormals': True,
          'producerSha256': hashlib.sha256(producer.read_bytes()).hexdigest(),
          'evidenceSha256': style['sourceBoundaryClosures'][target['sourceId']]['evidence']['sha256'],
          'scope': 'Pure producer geometry proof; exported per-source attributes, materials, transforms and browser appearance require separate audits.'}
output = ROOT / 'artifacts/neighborhood-20261024/art/candidate-11-source-proof.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
