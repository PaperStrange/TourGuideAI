import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const root = '/workspace/TourGuideAI';
const directory = path.join(root, 'artifacts/neighborhood-20261024/art/candidate-11-transport');
const baseline = path.join(root, 'artifacts/neighborhood-20261024/art/candidate-10-transport');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async file => JSON.parse(await fs.readFile(file));
const manifestBytes = await fs.readFile(path.join(directory, 'manifest.json'));
const manifest = JSON.parse(manifestBytes);
const previous = await json(path.join(baseline, 'manifest.json'));
const geographyPath = path.join(root, 'experience/src/neighborhoods/shijo-east/geography.json');
const geography = await json(geographyPath);
assert.deepEqual(manifest.featureTable, previous.featureTable);
const byFile = records => [...records].sort((left, right) => left.file.localeCompare(right.file));
assert.deepEqual(byFile(manifest.sharedResources), byFile(previous.sharedResources));
const shared = [];
for (const record of previous.sharedResources) {
  const before = await fs.readFile(path.join(baseline, record.file));
  const after = await fs.readFile(path.join(directory, record.file));
  assert.ok(before.equals(after), record.file);
  shared.push({ file: record.file, bytes: after.length, sha256: hash(after) });
}
assert.ok((await fs.readFile(path.join(baseline, 'lighting.json'))).equals(await fs.readFile(path.join(directory, 'lighting.json'))));
const spawnCells = manifest.cells.filter(cell => geography.spawn.x >= cell.bounds.minX && geography.spawn.x <= cell.bounds.maxX && geography.spawn.y >= cell.bounds.minY && geography.spawn.y <= cell.bounds.maxY);
assert.equal(spawnCells.length, 1);
const resources = new Map();
for (const descriptor of [manifest.ground, manifest.context, manifest.lighting, spawnCells[0].base]) {
  for (const record of [descriptor, ...descriptor.dependencies]) resources.set(record.file, record);
}
let commonBytes = manifestBytes.length;
for (const record of resources.values()) {
  const transfer = record.transport ?? record;
  const bytes = await fs.readFile(path.join(directory, transfer.file));
  assert.equal(hash(bytes), transfer.sha256);
  assert.equal(bytes.length, transfer.bytes);
  commonBytes += bytes.length;
}
const traveller = await fs.readFile(path.join(root, 'experience/public/models/traveller.glb'));
const rig = await json(path.join(directory, manifest.lighting.file));
const critical = {};
for (const mode of ['day', 'night']) {
  const environment = rig.modes[mode].environment;
  const hdr = await fs.readFile(path.resolve(directory, path.dirname(manifest.lighting.file), environment.file));
  assert.equal(hash(hdr), environment.sha256);
  const totalBytes = commonBytes + traveller.length + hdr.length;
  assert.ok(totalBytes <= 4194304);
  critical[mode] = { commonBytes, travellerBytes: traveller.length, hdrBytes: hdr.length,
    totalBytes, headroomBytes: 4194304 - totalBytes, limitBytes: 4194304, hdrSha256: hash(hdr) };
}
const compression = await json(path.join(directory, 'compression-report.json'));
assert.equal(compression.assets.length, 74);
for (const asset of compression.assets) {
  assert.equal(asset.inputIssues.numErrors, 0);
  assert.equal(asset.outputIssues.numErrors, 0);
  assert.equal(asset.maximumPositionErrorMetres, 0);
  assert.equal(asset.maximumUVError, 0);
  assert.equal(asset.sourceIndicesExact, true);
}
const transport = await json(path.join(directory, 'transport-report.json'));
const provenance = await json(path.join(directory, 'provenance.json'));
const beforeProvenance = await json(path.join(baseline, 'provenance.json'));
for (const key of ['geographySha256', 'sceneSha256', 'preparedArtSha256', 'preparedArtProducerSha256']) {
  assert.equal(provenance[key], beforeProvenance[key]);
}
assert.deepEqual(provenance.riverContext.input, beforeProvenance.riverContext.input);
const descriptors = [manifest.ground, manifest.context, ...manifest.cells.flatMap(cell => [cell.base, cell.near])];
const differences = [];
for (const descriptor of descriptors) {
  const current = await fs.readFile(path.join(directory, descriptor.file));
  const old = await fs.readFile(path.join(baseline, descriptor.file));
  if (!current.equals(old)) differences.push({ file: descriptor.file, sha256: hash(current), decodedGeometryBytes: descriptor.geometryBytes,
    transferGeometryBytes: descriptor.transferGeometryBytes, transferBudgetBytes: descriptor.transferBudgetBytes });
}
const report = {
  status: 'pass', manifestSha256: hash(manifestBytes), baselineManifestSha256: hash(await fs.readFile(path.join(baseline, 'manifest.json'))),
  producerSha256: hash(await fs.readFile(new URL(import.meta.url))), validatedContainers: 74,
  sourceTableExact: true, sharedResourcesExact: shared, addedImageBytes: 0, lightingRigExact: true,
  sourceInputHashesExact: true, critical, startupCellId: spawnCells[0].id,
  startupMeaning: 'Manifest, resident ground/context, opening BASE and deduplicated resources plus traveller and selected HDR; application HTML/JS/CSS/fonts and deferred sections are separate.',
  sourceBoundaryClosures: provenance.sourceBoundaryClosures, changedContainerIdentities: differences,
  sectionBudgets: transport.sectionBudgets,
  limits: 'Independent decoded per-source geometry/material/transform and walkable-mesh audit plus matched browser review remain required.'
};
await fs.writeFile(path.join(root, 'artifacts/neighborhood-20261024/art/candidate-11-resource-audit.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, manifest: report.manifestSha256, critical, changedContainers: differences.length, validatedContainers: 74, addedImageBytes: 0 }));
