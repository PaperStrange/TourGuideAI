import argparse
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path('/workspace/TourGuideAI')
sys.path.insert(0, str(ROOT / 'experience/art'))
from neighborhood_mesh import MeshBatch, wall_less_geometry
from neighborhood_landmarks import landmark_geometry


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def geometry_record(batches):
    return {name: {'vertices': batch.vertices, 'faces': batch.faces, 'sourceIndices': batch.source_indices}
            for name, batch in batches.items() if batch.faces}


parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('snapshot', 'verify'))
args = parser.parse_args()
style = json.loads((ROOT / 'experience/art/neighborhood-style.json').read_text())
scene = json.loads((ROOT / 'experience/src/neighborhoods/shijo-east/scene.json').read_text())
platform_id = 'kyoto-city:bldg_74454289-1d7a-4105-87ea-26e36c69bc44'
platform = next(feature.copy() for feature in scene['features'] if feature['sourceId'] == platform_id)
platform['treatmentOverride'] = style['sourceTreatmentOverrides'][platform_id]
torii = next(feature.copy() for feature in scene['landmarks'] if feature['sourceId'] == 'osm:node:5204263033')
override = style.get('landmarkMaterialOverrides', {}).get(torii['sourceId'])
if override:
    torii['hangingMaterial'] = override['hangingMaterial']
record = {'materials': style['materials'], 'torii': {}}
for lod in ('base', 'near'):
    batches = {name: MeshBatch() for name in style['materials']}
    landmark_geometry(torii, lod, 1047, batches)
    record['torii'][lod] = geometry_record(batches)
batches = {name: MeshBatch() for name in style['materials']}
wall_less_geometry(platform, 223, batches)
record['platform'] = geometry_record(batches)
baseline_path = ROOT / 'artifacts/neighborhood-20261024/art/source-baseline.json'
if args.mode == 'snapshot':
    if baseline_path.exists():
        raise ValueError('Preserved source baseline already exists')
    baseline_path.parent.mkdir(parents=True, exist_ok=True)
    baseline_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': 'snapshot', 'sha256': digest(record)}))
else:
    previous = json.loads(baseline_path.read_text())
    # JSON 统一元组与数组，按有向面和材质保留原始几何。
    record = json.loads(json.dumps(record))
    if any(record['materials'][name] != value for name, value in previous['materials'].items()):
        raise ValueError('Existing material definition changed')
    for lod in ('base', 'near'):
        mapped = dict(record['torii'][lod])
        if 'torii-paper' in mapped:
            mapped['lamp'] = mapped.pop('torii-paper')
        if mapped != previous['torii'][lod]:
            raise ValueError('Torii geometry or source attributes changed')
    for name, old in previous['platform'].items():
        current = record['platform'][name]
        if name != 'paving':
            if current != old:
                raise ValueError('Platform roof or supports changed')
        elif (current['vertices'][:len(old['vertices'])] != old['vertices'] or
              current['faces'][:len(old['faces'])] != old['faces'] or
              current['sourceIndices'][:len(old['sourceIndices'])] != old['sourceIndices']):
            raise ValueError('Platform top changed')
    current, old = record['platform']['paving'], previous['platform']['paving']
    added_faces = current['faces'][len(old['faces']):]
    if len(added_faces) != 4 or any(len(face) != 4 for face in added_faces):
        raise ValueError('Expected four vertical boundary faces')
    ring = platform['polygons'][0]['outer'][:-1]
    expected_xy = {(x, y) for x, y in ring}
    for face in added_faces:
        points = [current['vertices'][index] for index in face]
        if {point[2] for point in points} != {0, -.04} or any(tuple(point[:2]) not in expected_xy for point in points):
            raise ValueError('Boundary closure leaves the approved ring or height interval')
        a, b, c = points[:3]
        normal = ((b[1] - a[1]) * (c[2] - a[2]), -(b[0] - a[0]) * (c[2] - a[2]))
        center = [sum(point[axis] for point in ring) / len(ring) for axis in (0, 1)]
        midpoint = [(a[axis] + b[axis]) / 2 for axis in (0, 1)]
        if sum(normal[axis] * (midpoint[axis] - center[axis]) for axis in (0, 1)) <= 0:
            raise ValueError('Boundary face must point outward')
    report = {'status': 'pass', 'baselineSha256': digest(previous), 'toriiGeometryExact': True,
              'existingMaterialsExact': True, 'platformRoofSupportsAndTopExact': True,
              'addedBoundaryFaces': len(added_faces), 'addedBoundaryTriangles': 8,
              'boundaryHeightsMetres': [-.04, 0], 'sourceIndices': [223, 1047],
              'scope': 'Pure source geometry and material comparison; exported glTF, budgets and actual rendering require independent checks.'}
    (baseline_path.parent / 'source-check.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))
