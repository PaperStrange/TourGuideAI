// 校验每个下载 ZIP、执行脚本和构建文件，再保存原始报告与图片。
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync, copyFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';

const root = '/workspace/TourGuideAI', edition = process.argv[2];
const candidates = {
  '12': { head: '06a2c496da689b5c18797b2f77ef1f03cb2857ab', package: 'e86aa1c715fb76cd111feae41a0383ee34005aefd64fe5c48eba7615676e5733', metadata: 'metadata-cancelled.json' },
  '13': { head: '28439744b6349b795ac0a50c20c5d45d735bb2ed', package: 'e8eed9146ea83accaf54769ff2aaaf5a902cfd344295e3348e11684e50838b0c', metadata: 'metadata-current.json' },
};
const candidate = candidates[edition];
if (!candidate) throw new Error('Unknown candidate');
const raw = join(root, 'artifacts/neighborhood-20261024/ci/candidate-' + edition);
const portable = join(root, 'experience/evidence/neighborhood-20261024/ci/candidate-' + edition);
const dist = join(root, 'artifacts/neighborhood-20261024/candidate-' + edition);
const metadata = JSON.parse(readFileSync(join(raw, candidate.metadata)));
if (metadata.headSha !== candidate.head) throw new Error('Unexpected source head');
const sha = value => createHash('sha256').update(value).digest('hex');
const files = [];
function collect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) collect(path);
    else { const data = readFileSync(path); files.push({ path: '/' + relative(dist, path), bytes: data.length, sha256: sha(data) }); }
  }
}
collect(dist); files.sort((a, b) => a.path.localeCompare(b.path));
if (files.length !== 446 || sha(JSON.stringify(files)) !== candidate.package) throw new Error('Immutable package differs');
mkdirSync(portable, { recursive: true });
function compressed(data, name) {
  const bytes = Buffer.isBuffer(data) ? data : Buffer.from(data), encoded = gzipSync(bytes, { level: 9 });
  if (!gunzipSync(encoded).equals(bytes)) throw new Error('Compression mismatch');
  writeFileSync(join(portable, name), encoded);
  return { file: name, bytes: encoded.length, sha256: sha(encoded), decodedBytes: bytes.length, decodedSha256: sha(bytes) };
}
const drivers = { homepage: 'browser-homepage.mjs', perspective: 'browser-perspective.mjs', solo: 'browser-solo.mjs',
  travel: 'browser-travel.mjs', original: 'browser-check.mjs', packs: 'browser-packs.mjs', walkthrough: 'browser-walkthrough.mjs', neighborhood: 'browser-neighborhood.mjs' };
const reports = [];
let ciPackage = null;
const localByPath = new Map(files.map(file => [file.path, file]));
const sourceMapProofs = [];
for (const artifact of metadata.artifacts) {
  const suite = ({ 'homepage-walkthrough-evidence': 'walkthrough', 'experience-browser-evidence': 'original' })[artifact.name]
    || artifact.name.replace('-browser-evidence', '').replace('original-walk', 'original');
  if (!drivers[suite] || artifact.workflow_run.head_sha !== candidate.head) throw new Error('Unexpected artifact source');
  const zipPath = join(raw, suite + '.zip');
  if (!existsSync(zipPath)) continue;
  const zip = readFileSync(zipPath);
  if ('sha256:' + sha(zip) !== artifact.digest || zip.length !== artifact.size_in_bytes) throw new Error('Artifact ZIP digest differs: ' + suite);
  const dir = join(raw, suite); mkdirSync(dir, { recursive: true });
  execFileSync('unzip', ['-oq', zipPath, '-d', dir]);
  const name = readdirSync(dir).find(value => value.endsWith('result.json'));
  const bytes = readFileSync(join(dir, name)), report = JSON.parse(bytes);
  if (sha(JSON.stringify(report.artifact.files)) !== report.artifact.manifestSha256
    || report.artifact.files.length !== files.length
    || report.artifact.files.some((file, index) => file.path !== files[index].path)) throw new Error('Report package paths or digest differ: ' + suite);
  if (ciPackage && ciPackage !== report.artifact.manifestSha256) throw new Error('CI suites served different packages');
  ciPackage = report.artifact.manifestSha256;
  const differences = report.artifact.files.filter(file => JSON.stringify(file) !== JSON.stringify(localByPath.get(file.path)));
  if (differences.length !== 21) throw new Error('Unexpected source-map difference count');
  for (const file of differences) {
    if (!file.path.endsWith('.js.map')) throw new Error('Executable or asset difference: ' + file.path);
    const localBytes = readFileSync(join(dist, file.path)), map = JSON.parse(localBytes);
    const originalSources = [...map.sources];
    map.sources = map.sources.map(path => path.replace(/^\.\.\/\.\.\/\.\.\/\.\.\/experience\//, '../../'));
    const normalized = Buffer.from(JSON.stringify(map));
    if (normalized.length !== file.bytes || sha(normalized) !== file.sha256) throw new Error('Source-path-only proof failed: ' + file.path);
    if (!sourceMapProofs.some(proof => proof.path === file.path)) {
      sourceMapProofs.push({ path: file.path, local: localByPath.get(file.path), ci: file,
        changedSources: originalSources.flatMap((path, index) => path === map.sources[index] ? [] : [{ index, local: path, ci: map.sources[index] }]),
        sourcePathOnlyHashProof: true, normalizedSha256: sha(normalized),
        retainedLocalMap: compressed(localBytes, file.path.slice('/assets/'.length) + '.local.gz') });
    }
  }
  const driverPath = 'experience/tests/' + drivers[suite];
  const driver = execFileSync('git', ['show', candidate.head + ':' + driverPath], { cwd: root });
  if (sha(driver) !== report.driverSha256) throw new Error('Executed source driver differs: ' + suite);
  const dependencies = [];
  for (const dependency of report.driverDependencies || []) {
    const path = 'experience/' + dependency.file;
    const data = execFileSync('git', ['show', candidate.head + ':' + path], { cwd: root });
    if (sha(data) !== dependency.sha256) throw new Error('Executed helper differs: ' + path);
    dependencies.push(compressed(data, suite + '-' + dependency.file.replaceAll('/', '-') + '.gz'));
  }
  const completed = Boolean(report.finishedAt || report.summary || Number.isSafeInteger(report.passed));
  const observedChecks = report.checks?.reduce((value, check) => {
    value[check.pass ? 'passed' : 'failed']++; return value;
  }, { passed: 0, failed: 0 }) ?? null;
  const summary = completed ? report.summary || { passed: report.passed, failed: report.failed } : null;
  const captureFiles = [];
  if (suite === 'neighborhood') {
    const captures = join(portable, 'captures'); mkdirSync(captures, { recursive: true });
    for (const shot of report.screenshots) {
      const image = readFileSync(join(dir, shot.file));
      if (sha(image) !== shot.sha256) throw new Error('CI screenshot differs: ' + shot.file);
      copyFileSync(join(dir, shot.file), join(captures, shot.file));
      captureFiles.push({ file: 'captures/' + shot.file, sha256: shot.sha256, bytes: image.length });
    }
  }
  reports.push({ suite, artifact: { id: artifact.id, name: artifact.name, zipSha256: sha(zip), zipBytes: zip.length,
    createdAt: artifact.created_at, sourceHead: artifact.workflow_run.head_sha }, summary, observedChecks,
    completion: completed ? 'completed' : 'interrupted-without-final-summary',
    packageSha256: ciPackage, localPackageSha256: candidate.package, packageFiles: files.length,
    exactFiles: files.length - differences.length, sourcePathOnlyMapDifferences: differences.length,
    report: compressed(bytes, name + '.gz'),
    driver: compressed(driver, drivers[suite] + '.gz'), dependencies, captureFiles });
}
const logPath = join(raw, 'source-preparation.log');
const sourceLog = existsSync(logPath) ? compressed(readFileSync(logPath), 'source-preparation.log.gz') : null;
writeFileSync(join(portable, 'observed-run.json'), JSON.stringify(metadata, null, 2) + '\n');
const binding = { runId: metadata.runId, headSha: candidate.head, implementationSha: candidate.head, observedAt: metadata.observedAt,
  packageSha256: ciPackage, localPackageSha256: candidate.package, packageFiles: files.length, reports, sourceLog,
  sourceMapProofs, localPackageManifest: compressed(JSON.stringify(files, null, 2) + '\n', 'local-package-manifest.json.gz'),
  verificationSource: compressed(readFileSync(new URL(import.meta.url)), 'archive-candidate.mjs.gz'),
  conclusion: metadata.conclusion || 'pending', completedBrowserChecks: reports.reduce((sum, value) => sum + (value.summary?.passed ?? 0), 0),
  completedBrowserFailures: reports.reduce((sum, value) => sum + (value.summary?.failed ?? 0), 0) };
writeFileSync(join(portable, 'verification.json'), JSON.stringify(binding, null, 2) + '\n');
console.log(JSON.stringify({ directory: portable, reports: reports.map(value => ({ suite: value.suite, summary: value.summary, observedChecks: value.observedChecks, completion: value.completion })),
  packageSha256: ciPackage, localPackageSha256: candidate.package, sourcePathOnlyMaps: sourceMapProofs.length,
  complete: binding.conclusion, checks: binding.completedBrowserChecks, failures: binding.completedBrowserFailures }));
