import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import * as THREE from '../../../experience/node_modules/three/build/three.module.js';
import { loadNeighborhoodGeometry } from '../../../experience/tests/helpers/neighborhood-geometry.mjs';
import { createCameraObstruction } from '../../../experience/src/runtime/camera-obstruction.js';
import { createGuidedCamera } from '../../../experience/src/runtime/camera.js';
import { getPack } from '../../../experience/src/packs/registry.js';

const repository = new URL('../../../', import.meta.url), sha = value => createHash('sha256').update(value).digest('hex');
const reportURL = new URL('artifacts/neighborhood-20261024/qa/candidate-12-camera-guidance/neighborhood-result.json', repository);
const bytes = await readFile(reportURL);
if (sha(bytes) !== 'e625fdcb2bd81daee2c47bbdf7d7b1b466feeeefe354816b2b0db918f1ba4cc8') throw new Error('Input report identity differs');
const source = JSON.parse(bytes), original = source.scenarios['actual-camera-guidance'].attempts;
const observed = original[0].before, player = structuredClone(observed.route.position);
const base = new URL('artifacts/neighborhood-20261024/candidate-12/assets/neighborhoods/shijo-east/', repository);
const manifestBytes = await readFile(new URL('manifest.json', base)), manifest = JSON.parse(manifestBytes);
if (sha(manifestBytes) !== source.source.manifestSha256) throw new Error('Manifest identity differs');
const report = { inputReportSha256: sha(bytes), packageSha256: source.artifact.manifestSha256,
  manifestSha256: sha(manifestBytes), runtime: [], calls: [], callbacks: [], steps: [] };
for (const path of ['experience/src/runtime/camera.js', 'experience/src/runtime/camera-obstruction.js', 'experience/src/runtime/camera-constraint-feedback.js']) {
  const actual = await readFile(new URL(path, repository));
  const pinned = execFileSync('git', ['show', '06a2c49:' + path], { cwd: fileURLToPath(repository) });
  if (!actual.equals(pinned)) throw new Error('Runtime changed since frozen12: ' + path);
  report.runtime.push({ path, sha256: sha(actual), commit: '06a2c496da689b5c18797b2f77ef1f03cb2857ab' });
}
const collision = createCameraObstruction((mesh, hit) => {
  if (mesh.userData.occlusionGroup?.startsWith('Canopy_') || mesh.userData.semanticGroup?.includes('Canopy')) return true;
  const index = mesh.geometry.getAttribute('_source_index')?.getX(hit.face.a);
  const feature = (mesh.userData.featureTable ?? manifest.featureTable)?.[index];
  return feature?.kind === 'building' || feature?.sourceId?.startsWith('kyoto-city:bldg_') === true;
});
const roots = [];
let phase = 'setup';
try {
  const assets = [manifest.context, ...observed.stream.cells.filter(cell => cell.level)
    .map(cell => manifest.cells.find(value => value.id === cell.id)[cell.level])];
  for (const asset of assets) {
    const root = await loadNeighborhoodGeometry(new URL(asset.file, base)); roots.push(root); collision.addRoot(root);
  }
  const rig = createGuidedCamera(null, player, false, () => {}, { solo: true, pack: getPack('shijo-east'),
    onConstraintChange(value) { report.callbacks.push({ phase, value }); } });
  rig.resize(observed.camera.projectionMatrix[5] / observed.camera.projectionMatrix[0], 1);
  rig.restorePose(observed.home.currentView.camera, player);
  rig.setObstructionResolver((camera, target, state, options) => {
    const result = collision.resolve(camera, target, state, options);
    report.calls.push({ phase, deltaMs: options.deltaMs, active: result.active, settling: result.settling,
      desiredAzimuth: Math.atan2(camera.position.x - target.x, camera.position.z - target.z),
      actualAzimuth: Math.atan2(result.position.x - result.target.x, result.position.z - result.target.z),
      actualDistance: result.actualDistance, angleOffset: result.angleOffset });
    return result;
  });
  rig.setInspecting(true);
  for (let step = 0; step < original.length; step++) {
    const before = rig.snapshot(); phase = 'input-' + step; rig.rotate(.08); phase = 'settle-' + step;
    let quiet = 0, previous = rig.snapshot();
    for (let frame = 0; frame < 100; frame++) {
      rig.follow(player, 100); rig.synchronizeCamera(100);
      const after = rig.snapshot();
      const unchanged = after.matrixWorld.every((value, index) => Math.abs(value - previous.matrixWorld[index]) < .00001);
      quiet = !after.obstruction.settling && unchanged ? quiet + 1 : 0; previous = after;
      if (quiet >= 3) break;
      if (frame === 99) throw new Error('Recorded replay did not settle');
    }
    const after = rig.snapshot();
    report.steps.push({ step, before, after, browserPositionDelta: new THREE.Vector3().fromArray(after.position)
      .distanceTo(new THREE.Vector3().fromArray(original[step].after.camera.position)) });
  }
} finally {
  collision.dispose();
  for (const root of roots) root.traverse(mesh => {
    mesh.geometry?.dispose(); for (const material of [mesh.material].flat()) material?.dispose();
  });
}
report.finishedAt = new Date().toISOString();
await writeFile(new URL('./camera-guidance-adoption.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ callbacks: report.callbacks, steps: report.steps.length,
  maximumBrowserPositionDelta: Math.max(...report.steps.map(step => step.browserPositionDelta)),
  synchronousCalls: report.calls.filter(call => call.phase === 'input-9' || call.phase === 'input-10') }));
