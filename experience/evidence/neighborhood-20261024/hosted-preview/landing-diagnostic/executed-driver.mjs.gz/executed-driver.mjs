// 验证实际 HTTPS 入口、原始构建字节和原生步行控件。
import { chromium } from '/workspace/TourGuideAI/experience/node_modules/playwright/index.mjs';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';

const root = '/workspace/TourGuideAI';
const base = new URL('https://paperstrange.github.io/TourGuideAI/previews/shijo-east-c13/app/');
const landing = new URL('../', base);
const output = resolve(process.env.EXPERIENCE_QA_OUTPUT || join(root, 'artifacts/neighborhood-20261024/qa/hosted-c13'));
const timeout = 120000;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const inventoryPath = join(root, 'experience/evidence/neighborhood-20261024/validation/candidate-13-canonical-package.json');
const inventoryBytes = readFileSync(inventoryPath), inventory = JSON.parse(inventoryBytes);
const expectedPackage = '65167ee402d6d59978b5f979de8c6987721ec891ffec1ce6127831d7c0dd354e';
if (inventory.packageSha256 !== expectedPackage || inventory.fileCount !== 446
  || sha(JSON.stringify(inventory.files)) !== expectedPackage) throw new Error('Canonical package identity differs');
const expectedFiles = new Map(inventory.files.map(file => [file.path, file]));
const geographyBytes = readFileSync(join(root, 'experience/src/neighborhoods/shijo-east/geography.json'));
const geography = JSON.parse(geographyBytes);
const order = geography.sights.map(sight => sight.id);
const market = geography.sights.find(sight => sight.id === 'nishiki-market');
mkdirSync(output, { recursive: true });
const driver = readFileSync(new URL(import.meta.url));
writeFileSync(join(output, 'executed-driver.mjs'), driver);
const report = { startedAt: new Date().toISOString(), driverSha256: sha(driver),
  artifact: { packageSha256: expectedPackage, fileCount: 446, inventorySha256: sha(inventoryBytes), files: inventory.files },
  source: { implementation: '28439744b6349b795ac0a50c20c5d45d735bb2ed', geographySha256: sha(geographyBytes) },
  conditions: { base: base.href, landing: landing.href, viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1,
    reducedMotion: 'no-preference', headless: true, timeoutMs: timeout, requestInterception: false, tlsVerification: true,
    scope: 'Bounded hosted entry and native controls; no full traversal, performance, physical-device or milestone-acceptance claim.' },
  checks: [], scenarios: {}, screenshots: [], errors: [] };
const persist = () => writeFileSync(join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n');
const check = (id, pass, evidence) => { report.checks.push({ id, pass: Boolean(pass), evidence }); persist(); console.log(`${pass ? 'PASS' : 'FAIL'} ${id}`); };
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const observe = page => page.evaluate(() => ({ home: window.__HOME__?.snapshot(), state: window.__TOUR_GAME__?.snapshot(),
  route: window.__TOUR_GAME__?.route(), ground: window.__TOUR_GAME__?.grounding(), camera: window.__TOUR_GAME__?.camera(),
  stream: window.__TOUR_GAME__?.streaming(), renderer: window.__TOUR_GAME__?.renderer(), inspection: window.__TOUR_GAME__?.inspection() }));
async function ready(page, mode) {
  await page.waitForFunction(mode => {
    const home = window.__HOME__?.snapshot(), renderer = window.__TOUR_GAME__?.renderer();
    return home?.pack?.packId === 'shijo-east' && home.sceneState === 'ready' && !home.neighborhood.busy
      && home.currentView?.packId === 'shijo-east' && renderer?.status === 'ready' && renderer.renderedFrames > 0
      && renderer.lighting?.phase === 'ready' && (!mode || renderer.lighting.mode === mode);
  }, mode);
}
async function settle(page) {
  await page.waitForFunction(() => {
    const stream = window.__TOUR_GAME__?.streaming();
    return stream && !stream.downloads.active && !stream.downloads.queued && !stream.attachments.active && !stream.attachments.queued;
  });
  const stream = await page.evaluate(() => window.__TOUR_GAME__.streaming());
  if (stream.cells.some(cell => cell.error || cell.state === 'failed' || cell.desired && (cell.state !== 'ready' || cell.level !== cell.desired))) {
    throw new Error('Requested hosted sections are incomplete');
  }
}
async function capture(page, name) {
  await page.evaluate(() => window.scrollTo(0, 0));
  const observed = await observe(page);
  const file = name + '.png'; await page.screenshot({ path: join(output, file), fullPage: true });
  report.screenshots.push({ file, sha256: sha(readFileSync(join(output, file))), observed }); persist();
}
let browser;
try {
  const address = process.env.HTTPS_PROXY || process.env.HTTP_PROXY, proxy = address ? new URL(address) : null;
  browser = await chromium.launch({ executablePath: process.env.EXPERIENCE_QA_CHROMIUM || '/workspace/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
    headless: true, args: ['--no-sandbox'], ...(proxy ? { proxy: { server: proxy.origin, bypass: 'localhost,127.0.0.1',
      ...(proxy.username ? { username: decodeURIComponent(proxy.username), password: decodeURIComponent(proxy.password) } : {}) } } : {}) });
  report.browser = browser.version();
  const introduction = await browser.newContext();
  const introductionPage = await introduction.newPage(); introductionPage.setDefaultTimeout(timeout);
  const introductionResponse = await introductionPage.goto(landing.href, { waitUntil: 'domcontentloaded', timeout });
  const links = await introductionPage.locator('a[href]').evaluateAll(nodes => nodes.map(node => ({ text: node.textContent, href: node.href })));
  const deepURL = locale => new URL('?mode=explore&pack=shijo-east&lang=' + locale, base).href;
  check('landing-has-real-english-and-chinese-deep-links', introductionResponse.status() === 200
    && ['en', 'zh'].every(locale => links.some(link => link.href === deepURL(locale))), { status: introductionResponse.status(), links });
  const desktopLinks = [];
  for (const locale of ['en', 'zh']) {
    const index = links.findIndex(link => link.href === deepURL(locale));
    if (index < 0) throw new Error('Landing deep link missing: ' + locale);
    desktopLinks.push({ locale, text: links[index].text, visible: await introductionPage.locator('a[href]').nth(index).isVisible() });
  }
  check('landing-english-and-chinese-links-are-visible', desktopLinks.every(link => link.visible && link.text.trim().length > 0), desktopLinks);
  await introductionPage.setViewportSize({ width: 390, height: 844 });
  const compactLinks = [];
  for (const locale of ['en', 'zh']) {
    const index = links.findIndex(link => link.href === deepURL(locale));
    const link = introductionPage.locator('a[href]').nth(index); await link.scrollIntoViewIfNeeded();
    compactLinks.push(await link.evaluate((node, locale) => {
      const rect = node.getBoundingClientRect(), x = rect.x + rect.width / 2, y = rect.y + rect.height / 2;
      return { locale, width: window.innerWidth, documentWidth: document.scrollingElement.scrollWidth,
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        hit: document.elementFromPoint(x, y)?.closest('a') === node };
    }, locale));
  }
  check('landing-390-pixel-links-fit-and-remain-reachable', compactLinks.every(link => link.documentWidth <= link.width
    && link.rect.x >= 0 && link.rect.x + link.rect.width <= link.width && link.rect.width > 0 && link.rect.height > 0 && link.hit), compactLinks);
  await introductionPage.evaluate(() => window.scrollTo(0, 0));
  const landingFile = 'landing-390.png'; await introductionPage.screenshot({ path: join(output, landingFile), fullPage: true });
  report.screenshots.push({ file: landingFile, sha256: sha(readFileSync(join(output, landingFile))), scope: 'Actual landing at390×844; both native link bounds and hit targets recorded.', links: compactLinks });
  await introduction.close();
  for (const locale of ['en', 'zh']) {
    const context = await browser.newContext({ viewport: report.conditions.viewport, deviceScaleFactor: 1, reducedMotion: 'no-preference' });
    const page = await context.newPage(); page.setDefaultTimeout(timeout);
    const record = report.scenarios[locale] = { url: deepURL(locale), responses: [], failedRequests: [], pageErrors: [], consoleErrors: [] };
    const pendingBodies = [];
    page.on('pageerror', error => record.pageErrors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') record.consoleErrors.push(message.text()); });
    page.on('requestfailed', request => record.failedRequests.push({ url: request.url(), error: request.failure()?.errorText }));
    page.on('response', response => {
      const url = new URL(response.url());
      if (url.origin !== base.origin || !url.pathname.startsWith(base.pathname)) return;
      const path = '/' + url.pathname.slice(base.pathname.length), logicalPath = path === '/' ? '/index.html' : path;
      const expected = expectedFiles.get(logicalPath);
      const entry = { url: url.href, path: logicalPath, status: response.status(), expected: expected || null };
      record.responses.push(entry);
      if (expected) pendingBodies.push(response.body().then(bytes => {
        entry.bytes = bytes.length; entry.sha256 = sha(bytes); entry.matches = bytes.length === expected.bytes && entry.sha256 === expected.sha256;
      }, error => { entry.bodyError = error.message; }));
    });
    await page.addInitScript(() => {
      window.__HOSTED_SMOKE_EVENTS__ = [];
      for (const type of ['click', 'keydown', 'keyup']) document.addEventListener(type, event => {
        window.__HOSTED_SMOKE_EVENTS__.push({ type, key: event.key || null, trusted: event.isTrusted,
          target: event.target?.closest?.('button')?.id || event.target?.closest?.('[data-journey-focus]')?.dataset.journeyFocus || event.target?.id || null,
          at: performance.now() });
      }, true);
    });
    try {
      const response = await page.goto(record.url, { waitUntil: 'domcontentloaded', timeout });
      await ready(page); await settle(page);
      const opening = await observe(page); record.opening = opening;
      check(locale + '-https-deep-entry-opens-reviewed-neighborhood', response.status() === 200 && page.url() === record.url
        && await page.locator('html').getAttribute('lang') === locale && opening.home.pack.packId === 'shijo-east'
        && opening.home.pack.revision === 1 && opening.ground.inside && Boolean(opening.ground.hit), opening);
      const visibleOrder = await page.locator('.journey-stops [data-journey-focus]').evaluateAll(nodes => nodes.map(node => node.dataset.journeyFocus));
      const label = await page.locator('#neighborhood-journey .journey-distance strong').innerText();
      check(locale + '-six-reviewed-sights-and-135-km-route', equal(visibleOrder, order)
        && equal(opening.home.neighborhood.selected, order) && Math.abs(opening.home.neighborhood.distanceMeters - geography.selectedRoute.lengthMetres) < 1e-6
        && label === '1.35 km', { visibleOrder, label, neighborhood: opening.home.neighborhood, sourceLengthMetres: geography.selectedRoute.lengthMetres });
      await capture(page, locale + '-hosted-opening');
      await page.locator('[data-journey-focus="nishiki-market"]').click();
      await page.waitForFunction(() => Boolean(window.__TOUR_GAME__.route().goal));
      const walking = await observe(page);
      const walkingUI = await page.locator('#journey-walk-target').innerText();
      await page.waitForFunction(start => Math.hypot(window.__TOUR_GAME__.route().position.x - start.x,
        window.__TOUR_GAME__.route().position.y - start.y) > .1, walking.route.position);
      const moved = await observe(page);
      check(locale + '-trusted-walk-to-moves-grounded-player-and-keeps-route', distance(walking.route.goal, market) < .15
        && distance(moved.route.position, walking.route.position) > .1 && moved.route.remainingDistanceMeters < walking.route.remainingDistanceMeters
        && moved.ground.inside && Boolean(moved.ground.hit) && equal(moved.home.neighborhood.selected, order)
        && walkingUI.length > 0 && await page.locator('#journey-stop').isVisible(), { walking, moved, walkingUI });
      await page.locator('#journey-stop').click();
      await page.waitForFunction(() => !window.__TOUR_GAME__.route().goal && !window.__TOUR_GAME__.snapshot().moving);
      const stopped = await observe(page); await page.waitForTimeout(1000); const held = await observe(page);
      check(locale + '-stop-retains-position-and-selected-route', distance(held.route.position, stopped.route.position) < .003
        && !held.route.goal && equal(held.home.neighborhood.selected, order), { stopped, held });
      await page.locator('#solo-inspect').click();
      const inspecting = await observe(page); await page.keyboard.press('Escape');
      await page.waitForFunction(() => !window.__TOUR_GAME__.inspection().enabled);
      const exited = await observe(page);
      check(locale + '-look-closer-and-escape-keep-walking-location', inspecting.inspection.enabled && !exited.inspection.enabled
        && distance(exited.route.position, stopped.route.position) < .003, { inspecting, exited });
      await page.locator('#lighting-night').click(); await ready(page, 'night'); await settle(page);
      const night = await observe(page);
      check(locale + '-actual-night-controls-retain-route-and-ground', night.renderer.lighting.mode === 'night'
        && night.ground.inside && Boolean(night.ground.hit) && equal(night.home.neighborhood.selected, order), night);
      await capture(page, locale + '-hosted-night-controls');
      record.trustedEvents = await page.evaluate(() => window.__HOSTED_SMOKE_EVENTS__);
      check(locale + '-native-input-events-are-trusted', record.trustedEvents.length > 0
        && record.trustedEvents.every(event => event.trusted) && record.trustedEvents.some(event => event.type === 'keydown' && event.key === 'Escape'), record.trustedEvents);
    } catch (error) {
      record.fatal = { name: error.name, message: error.message, stack: error.stack };
      check(locale + '-hosted-sequence-completed', false, record.fatal);
      if (!page.isClosed()) await capture(page, locale + '-hosted-failure');
    }
    await Promise.all(pendingBodies);
    const completed = record.responses.filter(response => response.expected);
    check(locale + '-completed-hosted-bytes-match-canonical-package', completed.some(response => response.path === '/index.html')
      && completed.some(response => response.path.endsWith('/manifest.json'))
      && completed.some(response => response.path.endsWith('.gltf.gz'))
      && completed.every(response => response.status === 200 && response.matches), completed);
    check(locale + '-no-page-or-shader-errors', record.pageErrors.length === 0 && record.consoleErrors.length === 0,
      { pageErrors: record.pageErrors, consoleErrors: record.consoleErrors, failedRequests: record.failedRequests });
    await context.close();
  }
} catch (error) {
  report.errors.push({ name: error.name, message: error.message, stack: error.stack });
  check('hosted-smoke-setup-completed', false, report.errors.at(-1));
} finally {
  if (browser) await browser.close();
  report.finishedAt = new Date().toISOString();
  report.summary = { passed: report.checks.filter(check => check.pass).length, failed: report.checks.filter(check => !check.pass).length };
  persist(); console.log(JSON.stringify(report.summary));
  if (report.summary.failed) process.exitCode = 1;
}
